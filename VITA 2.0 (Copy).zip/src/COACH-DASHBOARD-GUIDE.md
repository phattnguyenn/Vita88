# Coach Dashboard Guide

## Overview
The VITA app now includes a complete Coach Dashboard interface - a separate command center for fitness coaches that's entirely different from the athlete user experience.

## Features

### 🎯 Sign Up Flow
- From the Auth page, users can choose to "Sign Up as Coach" or "Sign Up as Athlete"
- Coach sign-ups are routed to a completely different dashboard
- Separate navigation and UI/UX from athlete interface

### 📊 Dashboard Components

#### 1. Header Section
- Personalized greeting: "Welcome back, Coach Omar 👋"
- Date range selector (This Week / Month / Custom)
- Compact profile icon and settings

#### 2. Earnings Summary Cards (Top Row)
Four minimal stat cards with gradient borders:
- 💰 **Total Earnings**: $2,840
- 📅 **Sessions This Week**: 18
- 🧍‍♂️ **Active Clients**: 12
- ⭐ **Avg. Rating**: 4.9

#### 3. Upcoming Sessions
Scrollable list of sessions with:
- Time, client name, sport emoji, session type
- Status indicators (Confirmed ✅ / Pending ⏳ / Completed ✅)
- Filter buttons: Today / Week / All
- Action buttons:
  - Mark as Complete
  - Reschedule
  - Message Client

#### 4. Client Management
Grid of current clients showing:
- Client photo and name
- Sport type with emoji
- Flow Index score
- Progress tags (Improving 📈 / Stable ⚖️ / At Risk ⚠️)
- Streak count

#### 5. Performance Analytics
Three comprehensive charts:
- **Bar Chart**: Weekly session volume
- **Line Chart**: Client retention over time
- **Pie Chart**: Sport distribution (Boxing, Yoga, Strength, Running)
- AI Insights card with coaching tips

#### 6. Income Breakdown
Revenue table by package type:
- 1-on-1 Boxing — $1,200
- Group Sessions — $680
- Online Plans — $960
- Toggle: Weekly / Monthly view

#### 7. Notifications & AI Suggestions
Smart alerts:
- "3 clients haven't booked this week — send reminder?"
- "You're trending +15% above last week's earnings"
- "New coach request: 2 users viewed your profile"

#### 8. Quick Stats Sidebar
Progress bars showing:
- This Week's Progress
- Session Completion Rate

#### 9. Footer CTA Bar (Sticky)
- **Add New Session** (Primary button)
- **View Coach Profile** (Secondary button)

## Design System

### Colors
- **Background**: #0A0A0A (very dark)
- **Card Background**: #0f0f0f with #1a1a1a accents
- **Primary Accent**: #c6ff00 (neon lime)
- **Secondary Text**: #9B9B9B
- **Status Colors**:
  - Confirmed: #c6ff00 (lime)
  - Pending: #ffa500 (orange)
  - Improving: #c6ff00 (lime)
  - Stable: #00d9ff (blue)
  - At Risk: #ffa500 (orange)

### Typography
- **Font**: System default with light weight (200) for logo
- **Logo**: VIT<span>Λ</span> with "COACH" badge
- **Headings**: White with various opacities
- **Body Text**: White/60 for secondary text

### Visual Elements
- **Card Radius**: 20-24px
- **Gradient Borders**: Bottom accent bars on stat cards
- **Border**: 1px solid white/10
- **Backdrop Blur**: Used on sticky headers/footers
- **Shadows**: Soft shadows for depth

## Technologies Used
- **React** + **TypeScript**
- **Recharts** for data visualization (Bar, Line, Pie charts)
- **Lucide React** for icons
- **Tailwind CSS** for styling

## Mock Data
The dashboard currently uses mock data for:
- Session information
- Client profiles
- Analytics charts
- Revenue data
- Notifications

In production, this would connect to your backend API.

## Navigation
- Coach dashboard has its own top navigation (no bottom tabs)
- Logout returns to Auth page and resets to athlete mode
- Completely isolated from athlete user flow

## Future Enhancements
Potential additions:
- Session scheduling calendar
- Client detail modals
- Real-time chat integration
- Payment processing
- Coach profile editor
- Advanced analytics
- Marketing tools
- Client progress tracking

## File Structure
```
/components
  ├── Auth.tsx (Updated with coach sign-up)
  ├── CoachDashboard.tsx (New - Main coach interface)
  └── ... (other athlete components)

/App.tsx (Updated with userMode state)
```

## Usage
1. Launch the app
2. Select "Sign Up as Coach" from the Auth page
3. Fill in coach details
4. Dashboard loads automatically
5. Access all coaching tools and analytics

---

**Design Philosophy**: The coach dashboard is designed as a powerful, data-rich command center that feels futuristic and motivational - not cluttered like traditional admin panels. Every visual element drives clarity, confidence, and momentum for the coach's business.
