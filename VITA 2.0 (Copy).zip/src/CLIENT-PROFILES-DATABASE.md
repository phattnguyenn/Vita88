# Client Profiles Database - Coach Interface

## Overview
Complete database of 24 diverse client profiles for the VITA Coach Dashboard, representing various sports, fitness levels, progress states, and training scenarios.

---

## Client Categories

### 🟢 High Performers (Flow Index 70+)
Elite athletes with exceptional consistency and progress.

**1. My Le - Gymnastics** 🤸‍♀️
- Flow Index: 81 | Streak: 22 days | Sessions: 134
- Status: Active | Trend: Improving
- Goals: Back handspring, Floor routine perfection
- Activity: High
- Profile: Dedicated gymnast with exceptional consistency

**2. Thu Nguyen - Meditation** 🧘‍♀️
- Flow Index: 85 | Streak: 30 days | Sessions: 180
- Status: Active | Trend: Improving
- Goals: Daily practice, Stress reduction
- Activity: High
- Profile: Mindfulness expert, perfect attendance, ready for upsell

**3. Minh Tran - CrossFit** 🏋️
- Flow Index: 77 | Streak: 18 days | Sessions: 156
- Status: Active | Trend: Improving
- Goals: Rx all WODs, 300lb back squat
- Activity: High
- Profile: CrossFit enthusiast pushing limits

**4. Kim Tran - Kickboxing** 🦵
- Flow Index: 74 | Streak: 16 days | Sessions: 102
- Status: Active | Trend: Improving
- Goals: Master roundhouse, Fight preparation
- Activity: High
- Profile: Fight-focused athlete in peak training

**5. Huy Nguyen - Boxing** 🥊
- Flow Index: 72 | Streak: 21 days | Sessions: 124
- Status: Active | Trend: Improving
- Goals: Master defensive movement, Improve 3-round stamina
- Activity: High
- Profile: Consistent boxer, about to hit major milestone

**6. Anh Nguyen - Swimming** 🏊
- Flow Index: 71 | Streak: 14 days | Sessions: 110
- Status: Active | Trend: Improving
- Goals: Olympic triathlon, 1500m under 22min
- Activity: High
- Profile: Triathlete with excellent technique

**7. Dung Pham - Powerlifting** 🏋️‍♂️
- Flow Index: 70 | Streak: 13 days | Sessions: 95
- Status: Active | Trend: Improving
- Goals: 500lb deadlift, Competition prep
- Activity: High
- Profile: Strength athlete preparing for competition

---

### 🟡 Solid Performers (Flow Index 60-69)
Consistent clients with good progress and engagement.

**8. Mai Pham - Boxing** 🥊
- Flow Index: 68 | Streak: 15 days | Sessions: 98
- Status: Active | Trend: Improving
- Goals: Win regional championship, Increase punch power
- Activity: High
- Profile: Competition-focused boxer in peak form

**9. Vy Pham - Barre** 🩰
- Flow Index: 67 | Streak: 10 days | Sessions: 84
- Status: Active | Trend: Improving
- Goals: Leg definition, Core control
- Activity: High
- Profile: Barre enthusiast with consistent progress

**10. Bao Nguyen - Climbing** 🧗
- Flow Index: 66 | Streak: 11 days | Sessions: 72
- Status: Active | Trend: Improving
- Goals: Lead climb 6a, Finger strength
- Activity: High
- Profile: Rock climber building technique

**11. Thao Nguyen - Pilates** 🤸
- Flow Index: 64 | Streak: 12 days | Sessions: 92
- Status: Active | Trend: Stable
- Goals: Core strength, Posture correction
- Activity: Medium
- Profile: Pilates practitioner focused on form

**12. Phong Vo - Functional Training** ⚡
- Flow Index: 63 | Streak: 9 days | Sessions: 78
- Status: Active | Trend: Stable
- Goals: Mobility improvement, Injury prevention
- Activity: Medium
- Profile: Functional fitness for longevity

**13. Duc Phan - Running** 🏃
- Flow Index: 62 | Streak: 10 days | Sessions: 75
- Status: Active | Trend: Improving
- Goals: Complete first marathon, Sub-4 hour finish
- Activity: High
- Profile: Marathon runner in training phase

**14. Trung Le - Surfing** 🏄
- Flow Index: 61 | Streak: 7 days | Sessions: 46
- Status: Active | Trend: Stable
- Goals: Duck dive mastery, Wave reading
- Activity: Medium
- Profile: Surfer developing ocean skills

**15. Hoa Le - Dance** 💃
- Flow Index: 60 | Streak: 7 days | Sessions: 54
- Status: Active | Trend: Stable
- Goals: Master salsa, Performance ready
- Activity: Medium
- Profile: Dance enthusiast preparing for showcase

**16. Hai Nguyen - Rowing** 🚣
- Flow Index: 59 | Streak: 8 days | Sessions: 64
- Status: Active | Trend: Stable
- Goals: 2k under 7min, Endurance
- Activity: Medium
- Profile: Rower focused on endurance metrics

---

### 🟠 Developing Athletes (Flow Index 50-59)
Newer clients or those rebuilding consistency.

**17. Linh Tran - Yoga** 🧘
- Flow Index: 58 | Streak: 8 days | Sessions: 86
- Status: Active | Trend: Improving
- Goals: 5-min headstand, Daily meditation
- Activity: Medium
- Profile: Yoga practitioner with exceptional flexibility gains

**18. Nhi Tran - Volleyball** 🏐
- Flow Index: 56 | Streak: 6 days | Sessions: 52
- Status: Active | Trend: Stable
- Goals: Jump serve, Block technique
- Activity: Medium
- Profile: Volleyball player developing skills

**19. Tuan Vo - Cycling** 🚴
- Flow Index: 55 | Streak: 6 days | Sessions: 48
- Status: Active | Trend: Stable
- Goals: Century ride (100km), Improve climbing
- Activity: Medium
- Profile: Cyclist building endurance

**20. Lan Pham - Tennis** 🎾
- Flow Index: 52 | Streak: 5 days | Sessions: 38
- Status: Active | Trend: Stable
- Goals: Improve serve, Backhand consistency
- Activity: Medium
- Profile: Tennis player refining technique

**21. Tam Nguyen - Badminton** 🏸
- Flow Index: 50 | Streak: 4 days | Sessions: 29
- Status: At Risk | Trend: Declining
- Alert: "Missing sessions - motivation needed"
- Goals: Smash power, Footwork speed
- Activity: Low
- Profile: ⚠️ NEEDS ATTENTION - Motivation dropping

---

### 🔴 At-Risk Clients (Flow Index <50 or Special Status)
Clients requiring immediate attention or in recovery.

**22. Quan Vo - Basketball** 🏀
- Flow Index: 48 | Streak: 2 days | Sessions: 31
- Status: At Risk | Trend: Declining
- Alert: "Attendance dropping - check in needed"
- Goals: 3-point consistency, Vertical jump
- Activity: Low
- Profile: ⚠️ NEEDS ATTENTION - Attendance pattern concerning

**23. Khoa Le - Strength** 💪
- Flow Index: 45 | Streak: 3 days | Sessions: 42
- Status: At Risk | Trend: At Risk
- Alert: "No training in 5 days - shoulder rehab"
- Goals: Shoulder recovery, Pain-free movements
- Activity: Low
- Profile: ⚠️ REHAB PHASE - Recovering from shoulder injury, needs support

---

## Sport Distribution

### Combat Sports (7 clients)
- Boxing: Huy Nguyen, Mai Pham
- Kickboxing: Kim Tran
- MMA: Long Pham
- Total: 4 clients

### Mind-Body (5 clients)
- Yoga: Linh Tran
- Meditation: Thu Nguyen
- Pilates: Thao Nguyen
- Barre: Vy Pham
- Dance: Hoa Le

### Strength & Power (4 clients)
- CrossFit: Minh Tran
- Powerlifting: Dung Pham
- Strength Training: Khoa Le
- Functional Training: Phong Vo

### Endurance Sports (5 clients)
- Running: Duc Phan
- Swimming/Triathlon: Anh Nguyen
- Cycling: Tuan Vo
- Rowing: Hai Nguyen
- Surfing: Trung Le

### Other Sports (3 clients)
- Climbing: Bao Nguyen
- Gymnastics: My Le
- Tennis: Lan Pham
- Volleyball: Nhi Tran
- Basketball: Quan Vo
- Badminton: Tam Nguyen

---

## Client Status Summary

### Active Clients: 21
- High performers maintaining excellent streaks
- Solid progress across all metrics
- Regular attendance

### At-Risk Clients: 3
1. **Khoa Le** - Shoulder rehab, needs encouragement
2. **Quan Vo** - Attendance dropping, motivation check needed
3. **Tam Nguyen** - Missing sessions, re-engagement required

### Inactive Clients: 0

---

## AI Alert Categories

### 🔴 Retention Alerts (3)
1. **Khoa Le** - 5 days no training (rehab phase)
2. **Quan Vo** - 4 days, attendance declining
3. **Tam Nguyen** - 6 days, motivation needed

### 🎉 Celebration Alerts (1)
1. **Huy Nguyen** - 21-day streak (tomorrow milestone)

### 🏆 Milestone Alerts (1)
1. **Thu Nguyen** - 30-day meditation streak achieved

---

## Flow Index Distribution

**80-89**: 2 clients (8%)
- Thu Nguyen (85), My Le (81)

**70-79**: 5 clients (21%)
- Minh Tran (77), Kim Tran (74), Huy Nguyen (72), Anh Nguyen (71), Dung Pham (70)

**60-69**: 8 clients (33%)
- Mai Pham (68), Vy Pham (67), Bao Nguyen (66), Thao Nguyen (64), Phong Vo (63), Duc Phan (62), Trung Le (61), Hoa Le (60)

**50-59**: 6 clients (25%)
- Hai Nguyen (59), Linh Tran (58), Nhi Tran (56), Tuan Vo (55), Lan Pham (52), Tam Nguyen (50)

**40-49**: 3 clients (13%)
- Quan Vo (48), Khoa Le (45)

**Average Flow Index**: 63.2

---

## Streak Distribution

### Long Streaks (15+ days): 6 clients
- Thu Nguyen (30), My Le (22), Huy Nguyen (21), Minh Tran (18), Kim Tran (16), Mai Pham (15)

### Medium Streaks (8-14 days): 9 clients
- Anh Nguyen (14), Dung Pham (13), Thao Nguyen (12), Bao Nguyen (11), Duc Phan (10), Vy Pham (10), Phong Vo (9), Long Pham (9), Hai Nguyen (8), Linh Tran (8)

### Short Streaks (1-7 days): 9 clients
- Hoa Le (7), Trung Le (7), Tuan Vo (6), Nhi Tran (6), Lan Pham (5), Tam Nguyen (4), Khoa Le (3), Quan Vo (2)

---

## Activity Level Distribution

### High Activity (11 clients - 46%)
Clients with 4+ sessions per week:
- Huy Nguyen, Mai Pham, Duc Phan, Anh Nguyen, Minh Tran, Long Pham, Kim Tran, Bao Nguyen, Dung Pham, My Le, Thu Nguyen, Vy Pham

### Medium Activity (10 clients - 42%)
Clients with 2-3 sessions per week:
- Linh Tran, Tuan Vo, Thao Nguyen, Hoa Le, Lan Pham, Hai Nguyen, Nhi Tran, Phong Vo, Trung Le

### Low Activity (3 clients - 12%)
At-risk clients with inconsistent attendance:
- Khoa Le, Quan Vo, Tam Nguyen

---

## Coach Action Items (AI-Powered)

### Immediate Attention Required (Next 24h)
1. ✅ **Celebrate Huy's 21-day streak milestone**
2. ⚠️ **Check in with Quan Vo** - attendance pattern concerning
3. ⚠️ **Reach out to Tam Nguyen** - 6 days inactive

### This Week Actions
1. 💪 **Support Khoa Le's rehab** - encouragement message
2. 🎁 **Upsell Thu Nguyen** - advanced mindfulness program
3. 📊 **Review declining clients** - personalized retention plans

### Celebration Opportunities
1. 🎉 **Thu Nguyen** - 30-day streak achieved
2. 🎯 **Huy Nguyen** - approaching major milestone
3. 🏆 **My Le** - 22-day consistency champion

---

## Search & Filter Scenarios

### Example Searches
- "Boxing" → Returns: Huy Nguyen, Mai Pham
- "High Activity" → Returns: 11 active clients
- "At Risk" → Returns: Khoa Le, Quan Vo, Tam Nguyen
- "Flow > 70" → Returns: 7 elite performers

### Common Filters
- **Sport-based**: Boxing, Yoga, CrossFit, etc.
- **Status-based**: Active, At Risk, Inactive
- **Sort options**: Flow Index, Name, Recent Activity

---

## Data Quality & Realism

### Realistic Elements
✅ Diverse sports representation (14 different activities)
✅ Varied experience levels (29 sessions to 180 sessions)
✅ Different streak lengths (2 to 30 days)
✅ Mix of genders and demographics
✅ Real injury scenarios (Khoa's shoulder rehab)
✅ Competition prep clients (Mai, Dung)
✅ Declining engagement patterns (Quan, Tam)
✅ Milestone celebrations (Thu, Huy)
✅ Beginner to elite progression paths

### Profile Depth
Each client includes:
- Unique photo (Unsplash images)
- Sport-specific emoji
- 2 personalized goals
- Flow Index with trend indicator
- Session history metrics
- Streak tracking
- Activity level classification
- Status badges
- Optional alerts for at-risk clients

---

## Integration Points

### Client Detail Screen
All 24 clients can be clicked to open full Client Detail view with:
- Complete performance charts
- Session history
- Coach notes
- Communication logs
- Goal tracking
- AI insights

### Navigation Flow
```
Clients Tab → Grid of 24 Clients → Click Any Card → Client Detail Screen
```

### AI Integration
- Retention risk detection (3 clients flagged)
- Milestone celebrations (2 opportunities)
- Engagement pattern analysis
- Personalized action recommendations

---

## Future Expansion Ideas

### Phase 2 Additions
- [ ] Add more demographics (age groups, locations)
- [ ] Injury history tracking
- [ ] Package/program enrollment status
- [ ] Payment history indicators
- [ ] Referral source tracking
- [ ] Client testimonial highlights
- [ ] Competition results
- [ ] Before/after progress photos

### Advanced Filtering
- [ ] Filter by goal type
- [ ] Filter by injury/rehab status
- [ ] Filter by program enrollment
- [ ] Filter by payment status
- [ ] Filter by last contact date

---

## Summary Statistics

**Total Clients**: 24
**Active**: 21 (87.5%)
**At Risk**: 3 (12.5%)
**Average Flow Index**: 63.2
**Total Sessions (All Clients)**: 2,089
**Average Sessions per Client**: 87
**Longest Streak**: 30 days (Thu Nguyen)
**Shortest Streak**: 2 days (Quan Vo)
**Sports Represented**: 24 different activities
**High Activity Clients**: 11 (46%)

---

**Status**: ✅ Complete - 24 Diverse Client Profiles
**Last Updated**: November 3, 2025
**Integration**: Fully functional in CoachClients.tsx
