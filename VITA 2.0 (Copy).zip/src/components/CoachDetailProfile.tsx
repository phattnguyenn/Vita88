import { useState } from "react";
import { ArrowLeft, MapPin, Star, Award, Shield, Play, ChevronRight, X, CheckCircle2, Users, TrendingUp, MessageCircle, Calendar, Dumbbell, Target, Flame, Zap, ChevronDown, Trophy } from "lucide-react";

interface CoachDetailProfileProps {
  coachId: string;
  onBack: () => void;
  onBookPackage?: (packageId: string) => void;
}

interface Review {
  id: string;
  clientName: string;
  clientImage: string;
  rating: number;
  date: string;
  comment: string;
  sport: string;
}

interface Package {
  id: string;
  name: string;
  sessions: number;
  duration: string;
  price: number;
  features: string[];
  popular?: boolean;
}

interface Certification {
  name: string;
  issuer: string;
  icon: string;
}

interface Achievement {
  title: string;
  icon: string;
}

interface CoachMedia {
  id: string;
  type: "video" | "image";
  thumbnail: string;
  title: string;
  duration?: string;
}

interface Coach {
  id: string;
  name: string;
  profileImage: string;
  verified: boolean;
  specialties: string[];
  yearsExperience: number;
  location: string;
  rating: number;
  totalReviews: number;
  clientsTrained: number;
  clientRetention: number;
  bio: string;
  philosophy: string;
  packages: Package[];
  reviews: Review[];
  certifications: Certification[];
  achievements: Achievement[];
  media: CoachMedia[];
}

const coachesData: Record<string, Coach> = {
  "marcus-johnson": {
    id: "marcus-johnson",
    name: "Marcus Johnson",
    profileImage: "https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=400&h=400&fit=crop",
    verified: true,
    specialties: ["Strength Training", "Powerlifting", "Hypertrophy"],
    yearsExperience: 12,
    location: "Dubai, UAE",
    rating: 4.9,
    totalReviews: 187,
    clientsTrained: 340,
    clientRetention: 94,
    bio: "Certified strength and conditioning specialist with 12+ years transforming athletes through intelligent programming.",
    philosophy: "My mission is to help athletes move with precision, power, and confidence. I design strength programs that build both performance and longevity through science-based training.",
    packages: [
      {
        id: "1",
        name: "Starter Strength",
        sessions: 12,
        duration: "4 Weeks",
        price: 2400,
        features: [
          "12 1-on-1 training sessions",
          "Custom strength program",
          "Form analysis & correction",
          "Nutrition guidance"
        ]
      },
      {
        id: "2",
        name: "Elite Transformation",
        sessions: 36,
        duration: "12 Weeks",
        price: 6480,
        features: [
          "36 1-on-1 sessions",
          "Personalized programming",
          "Weekly progress tracking",
          "Nutrition & recovery plan",
          "Video form reviews"
        ],
        popular: true
      },
      {
        id: "3",
        name: "Performance Mastery",
        sessions: 72,
        duration: "6 Months",
        price: 11880,
        features: [
          "72 1-on-1 sessions",
          "Full periodization plan",
          "24/7 coaching support",
          "Advanced analytics",
          "Supplement guidance",
          "Competition prep (optional)"
        ]
      }
    ],
    reviews: [
      {
        id: "1",
        clientName: "Sarah Mitchell",
        clientImage: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop",
        rating: 5,
        date: "2 weeks ago",
        comment: "Marcus transformed my deadlift from 60kg to 140kg in 6 months. His attention to form and progressive programming is unmatched!",
        sport: "Strength Training"
      },
      {
        id: "2",
        clientName: "David Chen",
        clientImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop",
        rating: 5,
        date: "1 month ago",
        comment: "Professional and motivating. Marcus knows exactly how to push you while keeping you safe. Best investment in my fitness journey.",
        sport: "Powerlifting"
      },
      {
        id: "3",
        clientName: "Aisha Al-Hashimi",
        clientImage: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop",
        rating: 5,
        date: "1 month ago",
        comment: "Started as a complete beginner and Marcus made everything approachable. Now I can't imagine my life without strength training!",
        sport: "Functional Strength"
      }
    ],
    certifications: [
      { name: "NSCA-CSCS", issuer: "Certified Strength & Conditioning Specialist", icon: "shield" },
      { name: "NASM-CPT", issuer: "Certified Personal Trainer", icon: "award" },
      { name: "USA Weightlifting", issuer: "Level 2 Coach", icon: "trophy" }
    ],
    achievements: [
      { title: "1000+ Sessions", icon: "target" },
      { title: "Top-Rated Coach 2025", icon: "star" },
      { title: "Elite Trainer Badge", icon: "award" }
    ],
    media: [
      {
        id: "1",
        type: "video",
        thumbnail: "https://images.unsplash.com/photo-1756115484694-009466dbaa67?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=600",
        title: "Deadlift Form Breakdown",
        duration: "2:30"
      },
      {
        id: "2",
        type: "video",
        thumbnail: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=600&h=400&fit=crop",
        title: "Squat Progression Guide",
        duration: "3:15"
      }
    ]
  },
  "jackson-hayes": {
    id: "jackson-hayes",
    name: "Jackson Hayes",
    profileImage: "https://images.unsplash.com/photo-1549719386-74dfcbf7dbed?w=400&h=400&fit=crop",
    verified: true,
    specialties: ["Boxing", "Fight Training", "Conditioning"],
    yearsExperience: 15,
    location: "Dubai, UAE",
    rating: 4.9,
    totalReviews: 156,
    clientsTrained: 280,
    clientRetention: 92,
    bio: "Former professional boxer with 15 years in the ring. I teach the sweet science - combining technical precision with explosive power.",
    philosophy: "My mission is to help fighters move with speed, power, and intelligence. I design boxing programs that build both technique and mental toughness.",
    packages: [
      {
        id: "1",
        name: "Boxing Fundamentals",
        sessions: 12,
        duration: "4 Weeks",
        price: 2160,
        features: [
          "12 1-on-1 sessions",
          "Stance & footwork basics",
          "Punch technique training",
          "Conditioning drills"
        ]
      },
      {
        id: "2",
        name: "Fighter Development",
        sessions: 36,
        duration: "12 Weeks",
        price: 5760,
        features: [
          "36 1-on-1 sessions",
          "Advanced combinations",
          "Sparring preparation",
          "Fight-specific conditioning",
          "Pad work mastery"
        ],
        popular: true
      },
      {
        id: "3",
        name: "Pro Training Program",
        sessions: 60,
        duration: "20 Weeks",
        price: 8400,
        features: [
          "60 1-on-1 sessions",
          "Competition preparation",
          "Strategic fight planning",
          "Advanced sparring",
          "Mental conditioning",
          "Recovery protocols"
        ]
      }
    ],
    reviews: [
      {
        id: "1",
        clientName: "Marcus Williams",
        clientImage: "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=100&h=100&fit=crop",
        rating: 5,
        date: "5 days ago",
        comment: "Jackson is the real deal. His boxing fundamentals are solid and he pushes you to be your best. Lost 12kg and gained serious skills.",
        sport: "Boxing"
      },
      {
        id: "2",
        clientName: "Tyler Brooks",
        clientImage: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop",
        rating: 5,
        date: "2 weeks ago",
        comment: "Went from zero to winning my first amateur fight in 6 months. Jackson's coaching is world-class.",
        sport: "Boxing"
      }
    ],
    certifications: [
      { name: "USA Boxing", issuer: "Coach Certification", icon: "shield" },
      { name: "Level 3", issuer: "Boxing Coach", icon: "award" },
      { name: "NASM-PES", issuer: "Performance Enhancement Specialist", icon: "trophy" }
    ],
    achievements: [
      { title: "Pro Fighter", icon: "trophy" },
      { title: "Champion Maker", icon: "star" },
      { title: "Elite Trainer", icon: "award" }
    ],
    media: [
      {
        id: "1",
        type: "video",
        thumbnail: "https://images.unsplash.com/photo-1549719386-74dfcbf7dbed?w=600&h=400&fit=crop",
        title: "Boxing Warm-up Routine",
        duration: "1:45"
      },
      {
        id: "2",
        type: "video",
        thumbnail: "https://images.unsplash.com/photo-1549476464-37392f717541?w=600&h=400&fit=crop",
        title: "Jab Cross Technique",
        duration: "2:20"
      }
    ]
  },
  "ahmed-al-rashid": {
    id: "ahmed-al-rashid",
    name: "Ahmed Al-Rashid",
    profileImage: "https://images.unsplash.com/photo-1568602471122-7832951cc4c5?w=400&h=400&fit=crop",
    verified: true,
    specialties: ["Running", "HIIT", "Endurance"],
    yearsExperience: 10,
    location: "Dubai, UAE",
    rating: 4.8,
    totalReviews: 142,
    clientsTrained: 265,
    clientRetention: 89,
    bio: "Marathon champion and certified running coach specializing in endurance building and HIIT training for all levels.",
    philosophy: "My mission is to help runners move with efficiency, endurance, and joy. I design training plans that build speed while preventing injury through smart progression.",
    packages: [
      {
        id: "1",
        name: "5K Ready",
        sessions: 16,
        duration: "6 Weeks",
        price: 1920,
        features: [
          "16 guided running sessions",
          "5K training plan",
          "Running form analysis",
          "Pacing strategies"
        ]
      },
      {
        id: "2",
        name: "Half Marathon Master",
        sessions: 24,
        duration: "12 Weeks",
        price: 4320,
        features: [
          "24 training sessions",
          "Progressive distance building",
          "Nutrition for endurance",
          "Race day strategy",
          "Recovery protocols"
        ],
        popular: true
      },
      {
        id: "3",
        name: "Marathon Champion",
        sessions: 36,
        duration: "16 Weeks",
        price: 6120,
        features: [
          "36 specialized sessions",
          "Full marathon preparation",
          "Peak week tapering",
          "Mental training",
          "Injury prevention",
          "Post-race recovery"
        ]
      }
    ],
    reviews: [
      {
        id: "1",
        clientName: "Michael Roberts",
        clientImage: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100&h=100&fit=crop",
        rating: 5,
        date: "1 week ago",
        comment: "Completed my first marathon thanks to Ahmed's structured training plan. He knew exactly how to build my endurance without injury!",
        sport: "Running"
      },
      {
        id: "2",
        clientName: "Fatima Hassan",
        clientImage: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop",
        rating: 5,
        date: "3 weeks ago",
        comment: "Lost 15kg with Ahmed's HIIT programs. The workouts are challenging but effective. He's incredibly motivating!",
        sport: "HIIT"
      }
    ],
    certifications: [
      { name: "RRCA", issuer: "Certified Running Coach", icon: "shield" },
      { name: "NASM-CPT", issuer: "Certified Personal Trainer", icon: "award" },
      { name: "USA Track & Field", issuer: "Level 1 Coach", icon: "trophy" }
    ],
    achievements: [
      { title: "Marathon Expert", icon: "trophy" },
      { title: "Top Endurance Coach", icon: "star" },
      { title: "12x Marathon Finisher", icon: "award" }
    ],
    media: [
      {
        id: "1",
        type: "video",
        thumbnail: "https://images.unsplash.com/photo-1758520706103-41d01f815640?w=600&h=400&fit=crop",
        title: "Running Form Tips",
        duration: "2:15"
      },
      {
        id: "2",
        type: "video",
        thumbnail: "https://images.unsplash.com/photo-1476480862126-209bfaa8edc8?w=600&h=400&fit=crop",
        title: "HIIT Cardio Routine",
        duration: "1:50"
      }
    ]
  },
  "elena-rodriguez": {
    id: "elena-rodriguez",
    name: "Elena Rodriguez",
    profileImage: "https://images.unsplash.com/photo-1518611012118-696072aa579a?w=400&h=400&fit=crop",
    verified: true,
    specialties: ["Yoga", "Mobility", "Recovery"],
    yearsExperience: 8,
    location: "Dubai, UAE",
    rating: 5.0,
    totalReviews: 203,
    clientsTrained: 420,
    clientRetention: 96,
    bio: "RYT-500 yoga instructor and mobility specialist with a holistic approach to wellness and athletic recovery.",
    philosophy: "My mission is to help athletes move with freedom, flexibility, and mindfulness. I design practices that enhance recovery and prevent injury through intelligent movement.",
    packages: [
      {
        id: "1",
        name: "Flexibility Fundamentals",
        sessions: 12,
        duration: "4 Weeks",
        price: 1680,
        features: [
          "12 yoga sessions",
          "Flexibility assessment",
          "Custom stretching routine",
          "Breathing techniques"
        ]
      },
      {
        id: "2",
        name: "Recovery & Wellness",
        sessions: 24,
        duration: "8 Weeks",
        price: 3120,
        features: [
          "24 guided sessions",
          "Yoga & mobility blend",
          "Stress reduction practices",
          "Recovery optimization",
          "Mindfulness training"
        ],
        popular: true
      },
      {
        id: "3",
        name: "Mobility Mastery",
        sessions: 48,
        duration: "12 Weeks",
        price: 5760,
        features: [
          "48 comprehensive sessions",
          "Advanced mobility work",
          "Injury prevention protocols",
          "Athletic performance enhancement",
          "Private workshops",
          "Lifetime flexibility plan"
        ]
      }
    ],
    reviews: [
      {
        id: "1",
        clientName: "Rachel Green",
        clientImage: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=100&h=100&fit=crop",
        rating: 5,
        date: "4 days ago",
        comment: "Elena's yoga classes are transformative. My flexibility improved dramatically and my chronic back pain is gone. She's a true healer.",
        sport: "Yoga"
      },
      {
        id: "2",
        clientName: "Omar Khalil",
        clientImage: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop",
        rating: 5,
        date: "2 weeks ago",
        comment: "As a CrossFit athlete, Elena's mobility work has been game-changing for my recovery and performance. Highly recommend!",
        sport: "Mobility"
      }
    ],
    certifications: [
      { name: "RYT-500", issuer: "Registered Yoga Teacher", icon: "shield" },
      { name: "FRC", issuer: "Mobility Specialist", icon: "award" },
      { name: "MBSR", issuer: "Mindfulness-Based Stress Reduction", icon: "trophy" }
    ],
    achievements: [
      { title: "Yoga Master", icon: "trophy" },
      { title: "Perfect 5.0 Rating", icon: "star" },
      { title: "1000+ Sessions", icon: "award" }
    ],
    media: [
      {
        id: "1",
        type: "video",
        thumbnail: "https://images.unsplash.com/photo-1552196527-9a20ba4db2c3?w=600&h=400&fit=crop",
        title: "Morning Yoga Flow",
        duration: "3:00"
      },
      {
        id: "2",
        type: "video",
        thumbnail: "https://images.unsplash.com/photo-1599901860904-17e6ed7083a0?w=600&h=400&fit=crop",
        title: "Mobility Routine",
        duration: "2:45"
      }
    ]
  },
  "sarah-mitchell": {
    id: "sarah-mitchell",
    name: "Sarah Mitchell",
    profileImage: "https://images.unsplash.com/photo-1594381898411-846e7d193883?w=400&h=400&fit=crop",
    verified: true,
    specialties: ["Tennis", "Agility", "Court Movement"],
    yearsExperience: 9,
    location: "Dubai, UAE",
    rating: 4.9,
    totalReviews: 134,
    clientsTrained: 215,
    clientRetention: 91,
    bio: "Former touring tennis pro and ITF Level 3 coach specializing in technique development and competitive play.",
    philosophy: "My mission is to help players move with precision, strategy, and confidence. I design tennis programs that build both technical skills and mental toughness for competitive success.",
    packages: [
      {
        id: "1",
        name: "Tennis Beginner",
        sessions: 12,
        duration: "6 Weeks",
        price: 2160,
        features: [
          "12 court sessions",
          "Fundamental strokes",
          "Footwork training",
          "Basic strategy"
        ]
      },
      {
        id: "2",
        name: "Competitive Player",
        sessions: 24,
        duration: "10 Weeks",
        price: 4320,
        features: [
          "24 advanced sessions",
          "Match play training",
          "Strategy development",
          "Tournament preparation",
          "Video analysis"
        ],
        popular: true
      },
      {
        id: "3",
        name: "Elite Tennis Program",
        sessions: 48,
        duration: "16 Weeks",
        price: 7680,
        features: [
          "48 intensive sessions",
          "Pro-level training",
          "Mental game coaching",
          "Fitness conditioning",
          "Tournament support",
          "Year-round programming"
        ]
      }
    ],
    reviews: [
      {
        id: "1",
        clientName: "James Parker",
        clientImage: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop",
        rating: 5,
        date: "1 week ago",
        comment: "Sarah transformed my serve from my weakest to strongest shot. Her technical knowledge and teaching style are exceptional!",
        sport: "Tennis"
      },
      {
        id: "2",
        clientName: "Lisa Chen",
        clientImage: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&h=100&fit=crop",
        rating: 5,
        date: "2 weeks ago",
        comment: "Went from beginner to winning local tournaments in 4 months. Sarah's coaching is professional and highly effective!",
        sport: "Tennis"
      }
    ],
    certifications: [
      { name: "ITF Level 3", issuer: "International Tennis Federation", icon: "shield" },
      { name: "USPTA", issuer: "Professional Tennis Registry", icon: "award" },
      { name: "Sports Science", issuer: "Performance Specialist", icon: "trophy" }
    ],
    achievements: [
      { title: "Pro Player", icon: "trophy" },
      { title: "Top Tennis Coach", icon: "star" },
      { title: "300+ Students", icon: "award" }
    ],
    media: [
      {
        id: "1",
        type: "video",
        thumbnail: "https://images.unsplash.com/photo-1683219503543-21f6cace5655?w=600&h=400&fit=crop",
        title: "Serve Technique",
        duration: "2:40"
      },
      {
        id: "2",
        type: "video",
        thumbnail: "https://images.unsplash.com/photo-1714741980848-5b0b77d2cd68?w=600&h=400&fit=crop",
        title: "Backhand Mastery",
        duration: "3:10"
      }
    ]
  },
  "carlos-rivera": {
    id: "carlos-rivera",
    name: "Carlos Rivera",
    profileImage: "https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?w=400&h=400&fit=crop",
    verified: true,
    specialties: ["Pickleball", "Court Strategy", "Doubles Play"],
    yearsExperience: 6,
    location: "Dubai, UAE",
    rating: 4.9,
    totalReviews: 98,
    clientsTrained: 180,
    clientRetention: 93,
    bio: "Professional pickleball coach and tournament player specializing in strategic play and competitive development.",
    philosophy: "My mission is to help players move with agility, think strategically, and dominate the court. I design pickleball programs that make learning fun while building competitive skills.",
    packages: [
      {
        id: "1",
        name: "Pickleball Basics",
        sessions: 8,
        duration: "4 Weeks",
        price: 1280,
        features: [
          "8 court sessions",
          "Basic rules & gameplay",
          "Dinking fundamentals",
          "Court positioning"
        ]
      },
      {
        id: "2",
        name: "Competitive Edge",
        sessions: 20,
        duration: "8 Weeks",
        price: 2800,
        features: [
          "20 training sessions",
          "Advanced strategies",
          "Doubles play mastery",
          "Tournament tactics",
          "Match analysis"
        ],
        popular: true
      },
      {
        id: "3",
        name: "Tournament Ready",
        sessions: 32,
        duration: "12 Weeks",
        price: 4160,
        features: [
          "32 intensive sessions",
          "Competition preparation",
          "Partner coordination",
          "Mental game training",
          "Tournament support",
          "Video breakdown"
        ]
      }
    ],
    reviews: [
      {
        id: "1",
        clientName: "Linda Foster",
        clientImage: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=100&h=100&fit=crop",
        rating: 5,
        date: "1 week ago",
        comment: "Carlos made pickleball so much fun! His teaching method is clear and effective. I went from beginner to winning local tournaments!",
        sport: "Pickleball"
      },
      {
        id: "2",
        clientName: "Robert Chang",
        clientImage: "https://images.unsplash.com/photo-1519345182560-3f2917c472ef?w=100&h=100&fit=crop",
        rating: 5,
        date: "2 weeks ago",
        comment: "Best pickleball coach in Dubai! Carlos knows the game inside out and his strategies work. My dinking game improved tremendously.",
        sport: "Pickleball"
      }
    ],
    certifications: [
      { name: "PPR", issuer: "Certified Professional", icon: "shield" },
      { name: "IPTPA Level 2", issuer: "Coach Certification", icon: "award" },
      { name: "USAPA", issuer: "Ambassador", icon: "trophy" }
    ],
    achievements: [
      { title: "Regional Champion", icon: "trophy" },
      { title: "Top Pickleball Coach", icon: "star" },
      { title: "Tournament Expert", icon: "award" }
    ],
    media: [
      {
        id: "1",
        type: "video",
        thumbnail: "https://images.unsplash.com/photo-1554068865-24cecd4e34b8?w=600&h=400&fit=crop",
        title: "Dinking Strategy",
        duration: "2:25"
      },
      {
        id: "2",
        type: "video",
        thumbnail: "https://images.unsplash.com/photo-1626224583764-f87db24ac4ea?w=600&h=400&fit=crop",
        title: "Court Positioning",
        duration: "3:05"
      }
    ]
  }
};

export function CoachDetailProfile({ coachId, onBack, onBookPackage }: CoachDetailProfileProps) {
  const [expandBio, setExpandBio] = useState(false);
  const [selectedVideo, setSelectedVideo] = useState<string | null>(null);
  const [reviewsToShow, setReviewsToShow] = useState(3);
  
  const coach = coachesData[coachId];

  if (!coach) {
    return (
      <div className="h-full bg-[#0f0f0f] text-white flex items-center justify-center">
        <div className="text-center">
          <p className="text-white/60">Coach not found</p>
          <button onClick={onBack} className="mt-4 text-[#c6ff00]">Go Back</button>
        </div>
      </div>
    );
  }

  const getSpecialtyIcon = (specialty: string) => {
    if (specialty.toLowerCase().includes('strength') || specialty.toLowerCase().includes('power')) return Dumbbell;
    if (specialty.toLowerCase().includes('boxing') || specialty.toLowerCase().includes('fight')) return Target;
    if (specialty.toLowerCase().includes('conditioning')) return Flame;
    return Zap;
  };

  return (
    <div className="h-full bg-[#0f0f0f] overflow-y-auto">
      <div className="max-w-md mx-auto pb-24">
        {/* Header Section - Coach Identity */}
        <div className="relative px-5 pt-5 pb-6 border-b border-white/10">
          {/* Back Button */}
          <button
            onClick={onBack}
            className="absolute top-5 left-5 w-10 h-10 bg-white/10 backdrop-blur-xl rounded-full flex items-center justify-center border border-white/20 hover:bg-white/20 transition-all duration-300 z-10"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>

          {/* Coach Profile */}
          <div className="flex flex-col items-center text-center pt-8">
            <div className="relative mb-4">
              <div className="w-24 h-24 rounded-2xl overflow-hidden border-2 border-[#c6ff00]/30">
                <img
                  src={coach.profileImage}
                  alt={coach.name}
                  className="w-full h-full object-cover"
                />
              </div>
              {coach.verified && (
                <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-[#c6ff00] rounded-full flex items-center justify-center border-2 border-[#0f0f0f]">
                  <CheckCircle2 className="w-5 h-5 text-black" strokeWidth={3} />
                </div>
              )}
            </div>

            <h1 className="text-white mb-2">{coach.name}</h1>

            {/* Specialty Tags */}
            <div className="flex flex-wrap justify-center gap-2 mb-3">
              {coach.specialties.map((specialty, idx) => {
                const IconComponent = getSpecialtyIcon(specialty);
                return (
                  <div
                    key={idx}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-white/5 border border-white/10 rounded-full text-sm"
                  >
                    <IconComponent className="w-4 h-4 text-[#c6ff00]" />
                    <span className="text-white/80">{specialty}</span>
                  </div>
                );
              })}
            </div>

            {/* Experience & Location */}
            <div className="flex items-center gap-4 text-sm text-white/60">
              <div className="flex items-center gap-1.5">
                <Award className="w-4 h-4 text-[#c6ff00]" />
                <span>{coach.yearsExperience} Years Experience</span>
              </div>
              <div className="flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-[#c6ff00]" />
                <span>{coach.location}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Stats & Credibility Bar */}
        <div className="px-5 py-5 grid grid-cols-4 gap-3">
          <div className="bg-[#1a1a1a] border border-white/10 rounded-xl p-3 text-center">
            <div className="flex items-center justify-center gap-1 mb-1">
              <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
              <span className="text-white">{coach.rating}</span>
            </div>
            <div className="text-xs text-white/40">Rating</div>
          </div>
          <div className="bg-[#1a1a1a] border border-white/10 rounded-xl p-3 text-center">
            <div className="flex items-center justify-center gap-1 mb-1">
              <Users className="w-4 h-4 text-blue-400" />
              <span className="text-white">{coach.clientsTrained}</span>
            </div>
            <div className="text-xs text-white/40">Clients</div>
          </div>
          <div className="bg-[#1a1a1a] border border-white/10 rounded-xl p-3 text-center">
            <div className="flex items-center justify-center gap-1 mb-1">
              <TrendingUp className="w-4 h-4 text-green-400" />
              <span className="text-white">{coach.clientRetention}%</span>
            </div>
            <div className="text-xs text-white/40">Retention</div>
          </div>
          <div className="bg-[#1a1a1a] border border-white/10 rounded-xl p-3 text-center">
            <div className="flex items-center justify-center gap-1 mb-1">
              <MessageCircle className="w-4 h-4 text-purple-400" />
              <span className="text-white">{coach.totalReviews}</span>
            </div>
            <div className="text-xs text-white/40">Reviews</div>
          </div>
        </div>

        {/* Bio & Philosophy Section */}
        <div className="px-5 mb-6">
          <div className="bg-[#1a1a1a] border border-white/10 rounded-2xl p-5">
            <h3 className="text-white mb-3">About & Philosophy</h3>
            <p className="text-white/70 text-sm leading-relaxed mb-2">{coach.bio}</p>
            {!expandBio && (
              <button
                onClick={() => setExpandBio(true)}
                className="text-[#c6ff00] text-sm flex items-center gap-1 hover:gap-2 transition-all duration-200"
              >
                <span>Read more</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            )}
            {expandBio && (
              <>
                <p className="text-white/60 text-sm leading-relaxed italic mt-3 pt-3 border-t border-white/10">
                  "{coach.philosophy}"
                </p>
                <button
                  onClick={() => setExpandBio(false)}
                  className="text-[#c6ff00] text-sm flex items-center gap-1 mt-3"
                >
                  <span>Show less</span>
                  <ChevronDown className="w-4 h-4" />
                </button>
              </>
            )}
          </div>
        </div>

        {/* Packages & Programs Section */}
        <div className="px-5 mb-6">
          <h3 className="text-white mb-4">Training Packages</h3>
          <div className="space-y-3">
            {coach.packages.map((pkg) => (
              <div
                key={pkg.id}
                className={`rounded-2xl p-5 border transition-all duration-300 hover:shadow-[0_8px_32px_rgba(0,0,0,0.4)] ${
                  pkg.popular
                    ? 'bg-gradient-to-br from-[#c6ff00]/10 to-[#b5e600]/5 border-[#c6ff00]/30'
                    : 'bg-[#1a1a1a] border-white/10'
                }`}
              >
                {pkg.popular && (
                  <div className="inline-flex items-center gap-1 px-2 py-1 bg-[#c6ff00] text-black text-xs rounded-full mb-3">
                    <Star className="w-3 h-3" fill="currentColor" />
                    <span>Most Popular</span>
                  </div>
                )}
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h4 className="text-white mb-1">{pkg.name}</h4>
                    <div className="flex items-center gap-3 text-sm text-white/60">
                      <div className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        <span>{pkg.duration}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Dumbbell className="w-4 h-4" />
                        <span>{pkg.sessions} sessions</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl text-[#c6ff00]">AED {pkg.price}</div>
                    <div className="text-xs text-white/40">Total</div>
                  </div>
                </div>

                <div className="space-y-2 mb-4">
                  {pkg.features.map((feature, idx) => (
                    <div key={idx} className="flex items-start gap-2 text-sm text-white/70">
                      <CheckCircle2 className="w-4 h-4 text-[#c6ff00] flex-shrink-0 mt-0.5" />
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>

                <button
                  onClick={() => onBookPackage?.(pkg.id)}
                  className={`w-full py-3 rounded-xl transition-all duration-200 flex items-center justify-center gap-2 ${
                    pkg.popular
                      ? 'bg-[#c6ff00] hover:bg-[#b5e600] text-black'
                      : 'bg-white/10 hover:bg-white/15 text-white border border-white/20'
                  }`}
                >
                  <span>Book Now</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Reviews & Testimonials Section */}
        <div className="px-5 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-white">Client Reviews</h3>
            <div className="flex items-center gap-1">
              <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
              <span className="text-white">{coach.rating}</span>
              <span className="text-white/40 text-sm">({coach.totalReviews})</span>
            </div>
          </div>

          <div className="space-y-3">
            {coach.reviews.slice(0, reviewsToShow).map((review) => (
              <div
                key={review.id}
                className="bg-[#1a1a1a] border border-white/10 rounded-xl p-4"
              >
                <div className="flex items-start gap-3 mb-3">
                  <img
                    src={review.clientImage}
                    alt={review.clientName}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <h4 className="text-white text-sm">{review.clientName}</h4>
                      <span className="text-xs text-white/40">{review.date}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex gap-0.5">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-3 h-3 ${
                              i < review.rating
                                ? 'text-yellow-400 fill-yellow-400'
                                : 'text-white/20'
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-xs px-2 py-0.5 bg-white/5 rounded text-white/60">
                        {review.sport}
                      </span>
                    </div>
                  </div>
                </div>
                <p className="text-white/70 text-sm leading-relaxed">"{review.comment}"</p>
              </div>
            ))}
          </div>

          {reviewsToShow < coach.reviews.length && (
            <button
              onClick={() => setReviewsToShow(coach.reviews.length)}
              className="w-full mt-3 py-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-white text-sm transition-all duration-200"
            >
              Show all {coach.reviews.length} reviews
            </button>
          )}
        </div>

        {/* Coach Media Section */}
        <div className="px-5 mb-6">
          <h3 className="text-white mb-4">Training Previews</h3>
          <div className="grid grid-cols-2 gap-3">
            {coach.media.map((media) => (
              <button
                key={media.id}
                onClick={() => setSelectedVideo(media.id)}
                className="relative aspect-video rounded-xl overflow-hidden group"
              >
                <img
                  src={media.thumbnail}
                  alt={media.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                
                {/* Play Button */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-12 h-12 bg-[#c6ff00]/90 backdrop-blur-xl rounded-full flex items-center justify-center group-hover:bg-[#c6ff00] transition-all duration-200">
                    <Play className="w-5 h-5 text-black ml-0.5" fill="currentColor" />
                  </div>
                </div>

                {/* Info */}
                <div className="absolute bottom-0 left-0 right-0 p-3">
                  <div className="text-white text-xs mb-1">{media.title}</div>
                  {media.duration && (
                    <div className="text-white/60 text-xs">{media.duration}</div>
                  )}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Certifications & Achievements Section */}
        <div className="px-5 mb-6">
          <h3 className="text-white mb-4">Certifications & Achievements</h3>
          
          {/* Certifications */}
          <div className="mb-4">
            <h4 className="text-white/60 text-sm mb-3">Professional Certifications</h4>
            <div className="space-y-2">
              {coach.certifications.map((cert, idx) => (
                <div
                  key={idx}
                  className="flex items-center gap-3 p-3 bg-[#1a1a1a] border border-white/10 rounded-xl"
                >
                  <div className="w-10 h-10 bg-[#c6ff00]/10 rounded-lg flex items-center justify-center border border-[#c6ff00]/30">
                    <Shield className="w-5 h-5 text-[#c6ff00]" />
                  </div>
                  <div className="flex-1">
                    <div className="text-white text-sm mb-0.5">{cert.name}</div>
                    <div className="text-white/40 text-xs">{cert.issuer}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Achievements */}
          <div>
            <h4 className="text-white/60 text-sm mb-3">Achievements & Milestones</h4>
            <div className="grid grid-cols-3 gap-3">
              {coach.achievements.map((achievement, idx) => (
                <div
                  key={idx}
                  className="bg-gradient-to-br from-[#c6ff00]/10 to-[#b5e600]/5 border border-[#c6ff00]/30 rounded-xl p-4 text-center"
                >
                  <div className="w-10 h-10 mx-auto mb-2 bg-[#c6ff00]/20 rounded-full flex items-center justify-center">
                    <Trophy className="w-5 h-5 text-[#c6ff00]" />
                  </div>
                  <div className="text-white text-xs leading-tight">{achievement.title}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Call to Action Footer - Sticky */}
      <div className="fixed bottom-0 left-0 right-0 bg-[#0f0f0f]/95 backdrop-blur-xl border-t border-white/10 z-20">
        <div className="max-w-md mx-auto px-5 py-4 flex gap-3">
          <button className="flex-1 py-3 bg-white/10 hover:bg-white/15 border border-white/20 text-white rounded-xl transition-all duration-200 flex items-center justify-center gap-2">
            <MessageCircle className="w-5 h-5" />
            <span>Message</span>
          </button>
          <button
            onClick={() => onBookPackage?.(coach.packages[0].id)}
            className="flex-1 py-3 bg-[#c6ff00] hover:bg-[#b5e600] text-black rounded-xl transition-all duration-200 flex items-center justify-center gap-2"
          >
            <Calendar className="w-5 h-5" />
            <span>Book Session</span>
          </button>
        </div>
      </div>

      {/* Video Modal */}
      {selectedVideo && (
        <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-sm flex items-center justify-center p-5">
          <div className="max-w-md w-full">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-white">Preview</h3>
              <button
                onClick={() => setSelectedVideo(null)}
                className="w-10 h-10 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center transition-all duration-200"
              >
                <X className="w-6 h-6 text-white" />
              </button>
            </div>
            <div className="aspect-video bg-[#1a1a1a] rounded-2xl flex items-center justify-center">
              <Play className="w-16 h-16 text-[#c6ff00]" />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}