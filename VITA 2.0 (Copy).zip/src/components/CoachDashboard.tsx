import { useState } from "react";
import { Bell, Settings } from "lucide-react";
import { CoachBottomNav } from "./CoachBottomNav";
import { CoachOverview } from "./CoachOverview";
import { CoachClients } from "./CoachClients";
import { CoachSessions } from "./CoachSessions";
import { CoachPackages } from "./CoachPackages";
import { CoachAI } from "./CoachAI";
import { CoachLibrary } from "./CoachLibrary";
import { CoachProfile } from "./CoachProfile";

interface CoachDashboardProps {
  onLogout: () => void;
  onClientSelect?: (clientId: string) => void;
}

export function CoachDashboard({ onLogout, onClientSelect }: CoachDashboardProps) {
  const [activeTab, setActiveTab] = useState<
    "dashboard" | "clients" | "sessions" | "packages" | "ai" | "library" | "profile"
  >("dashboard");

  return (
    <div className="h-screen w-screen bg-[#0A0A0A] flex flex-col overflow-hidden">
      {/* Top Header Bar - Fixed across all tabs */}
      <div className="flex-shrink-0 bg-[#0f0f0f]/95 backdrop-blur-xl border-b border-white/10 z-50">
        <div className="max-w-7xl mx-auto px-5 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h1 className="text-white text-2xl" style={{ fontWeight: 200, letterSpacing: "0.1em" }}>
              VIT<span className="inline-block" style={{ transform: "scaleX(-1)" }}>Λ</span>
            </h1>
            <span className="px-2 py-0.5 bg-[#c6ff00]/20 text-[#c6ff00] rounded text-xs">
              COACH
            </span>
          </div>
          
          <div className="flex items-center gap-3">
            <button className="relative p-2 hover:bg-white/5 rounded-lg transition-colors">
              <Bell className="w-5 h-5 text-white/60" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-[#c6ff00] rounded-full" />
            </button>
            <button className="p-2 hover:bg-white/5 rounded-lg transition-colors">
              <Settings className="w-5 h-5 text-white/60" />
            </button>
            <img
              src="https://images.unsplash.com/photo-1568602471122-7832951cc4c5?w=400&h=400&fit=crop"
              alt="Coach"
              className="w-8 h-8 rounded-full object-cover ring-2 ring-white/10"
            />
          </div>
        </div>
      </div>

      {/* Content Area - Scrollable */}
      <div className="flex-1 overflow-y-auto overflow-x-hidden">
        {activeTab === "dashboard" && <CoachOverview />}
        {activeTab === "clients" && (
          <CoachClients onClientSelect={onClientSelect || (() => {})} />
        )}
        {activeTab === "sessions" && <CoachSessions />}
        {activeTab === "packages" && <CoachPackages />}
        {activeTab === "ai" && <CoachAI />}
        {activeTab === "library" && <CoachLibrary />}
        {activeTab === "profile" && <CoachProfile onLogout={onLogout} />}
      </div>

      {/* Bottom Navigation */}
      <div className="flex-shrink-0">
        <CoachBottomNav activeTab={activeTab} onTabChange={setActiveTab} />
      </div>
    </div>
  );
}
