import { useState } from "react";
import { Send, Sparkles, ChevronRight, Clock, Dumbbell, Trophy, X, MapPin, TrendingUp, Flame, Target, Zap, Award, ChevronDown, Star, ArrowRight, Lightbulb, Gift } from "lucide-react";

interface Package {
  id: string;
  title: string;
  duration: string;
  goal: string;
  image: string;
  category: string;
  difficulty: "Beginner" | "Intermediate" | "Advanced";
  coaches: {
    type: string;
    name: string;
    image: string;
    sport: string;
    sessions: number;
    focus: string;
  }[];
  description: string;
  highlights: string[];
  expectedResults: string[];
}

interface PerformanceItem {
  id: string;
  type: "milestone" | "ranking" | "achievement";
  userName: string;
  userAvatar: string;
  text: string;
  metric?: string;
  icon: "trophy" | "flame" | "target" | "zap";
  timestamp: string;
  sport?: string;
}

interface CoachSpotlightItem {
  id: string;
  coachName: string;
  coachAvatar: string;
  coachSport: string;
  type: "tip" | "transformation" | "offer";
  title: string;
  content: string;
  image?: string;
  ctaText?: string;
  timestamp: string;
}

interface AICuratedItem {
  id: string;
  title: string;
  description: string;
  reason: string;
  image: string;
  sport: string;
  type: "routine" | "coach" | "package";
  ctaText: string;
}

const packages: Package[] = [
  {
    id: "1",
    title: "Get a 6-Pack in 90 Days",
    duration: "90 Days",
    goal: "Sculpted Core & Definition",
    image: "https://images.unsplash.com/photo-1559146039-f3a4ed3e470a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    category: "Body Transformation",
    difficulty: "Intermediate",
    coaches: [
      {
        type: "Weight Training",
        name: "Marcus Johnson",
        image: "https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=400&h=400&fit=crop",
        sport: "Strength Training",
        sessions: 36,
        focus: "Core strength, compound movements, progressive overload"
      },
      {
        type: "Cardio Coach",
        name: "Ahmed Al-Rashid",
        image: "https://images.unsplash.com/photo-1568602471122-7832951cc4c5?w=400&h=400&fit=crop",
        sport: "Running & HIIT",
        sessions: 24,
        focus: "Fat burning HIIT, metabolic conditioning, endurance"
      }
    ],
    description: "Complete body transformation program designed to reveal your abs through a combination of targeted strength training, high-intensity cardio, strategic sports conditioning, and proper recovery protocols.",
    highlights: [
      "3 strength sessions per week focusing on core and full-body",
      "2-3 HIIT cardio sessions for maximum fat burn",
      "Weekly pickleball sessions for active recovery",
      "2 yoga sessions per week for flexibility and recovery",
      "Personalized nutrition guidance included",
      "Progress tracking and body composition analysis"
    ],
    expectedResults: [
      "Visible abdominal definition within 90 days",
      "10-15% reduction in body fat percentage",
      "Increased core strength and stability",
      "Improved cardiovascular endurance",
      "Enhanced overall athletic performance"
    ]
  },
  {
    id: "2",
    title: "Tennis Mastery for Beginners",
    duration: "60 Days",
    goal: "From Zero to Rally Ready",
    image: "https://images.unsplash.com/photo-1714741980848-5b0b77d2cd68?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    category: "Sport Specialization",
    difficulty: "Beginner",
    coaches: [
      {
        type: "Tennis Coach",
        name: "Sarah Mitchell",
        image: "https://images.unsplash.com/photo-1594381898411-846e7d193883?w=400&h=400&fit=crop",
        sport: "Tennis",
        sessions: 24,
        focus: "Technique fundamentals, footwork, match strategy"
      }
    ],
    description: "Comprehensive tennis program that takes complete beginners to confident rally players through expert technique coaching, tennis-specific fitness, and proper recovery protocols.",
    highlights: [
      "4 tennis sessions per week with progressive skill development",
      "2 strength sessions focusing on tennis-specific movements",
      "Weekly cardio conditioning for court endurance"
    ],
    expectedResults: [
      "Master basic strokes (forehand, backhand, serve)",
      "Confident rally ability with proper technique",
      "Understanding of court positioning and strategy"
    ]
  },
  {
    id: "3",
    title: "Boxing Journey: Beginner to Fighter",
    duration: "120 Days",
    goal: "Complete Boxing Foundation",
    image: "https://images.unsplash.com/photo-1570312530820-d0f15f33a4a9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    category: "Combat Sports",
    difficulty: "Beginner",
    coaches: [
      {
        type: "Boxing Coach",
        name: "Jackson Hayes",
        image: "https://images.unsplash.com/photo-1549719386-74dfcbf7dbed?w=400&h=400&fit=crop",
        sport: "Boxing",
        sessions: 48,
        focus: "Technique, combinations, defensive skills, sparring"
      }
    ],
    description: "Transform from complete beginner to competent boxer with a comprehensive 4-month program covering all aspects of boxing technique, conditioning, and mental preparation.",
    highlights: [
      "4 boxing sessions per week with progressive skill building",
      "2 strength training sessions for explosive power",
      "2 conditioning sessions for boxing-specific endurance"
    ],
    expectedResults: [
      "Master fundamental boxing techniques and combinations",
      "Develop powerful, accurate punches",
      "Build boxing-specific conditioning and endurance"
    ]
  }
];

const weeklyHighlights = {
  title: "Your Week at a Glance",
  weekOf: "Oct 24 - Oct 30",
  stats: {
    sessions: 5,
    calories: 2450,
    streak: 12
  },
  achievements: [
    { icon: "flame", text: "12-day training streak" },
    { icon: "target", text: "Hit 5/5 planned sessions" },
    { icon: "dumbbell", text: "New deadlift PR: 120kg" }
  ],
  coachUpdate: {
    coachName: "Marcus Johnson",
    message: "Sofia, incredible week! Your form on squats has improved dramatically. Let's push for 6 sessions next week.",
    avatar: "https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=400&h=400&fit=crop"
  },
  communitySpotlight: "Sofia Martinez reached 100 sessions milestone! Join 47 others celebrating this week."
};

const performanceFeed: PerformanceItem[] = [
  {
    id: "perf-1",
    type: "milestone",
    userName: "David Chen",
    userAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop",
    text: "Hit 10 sessions this month",
    metric: "10 sessions",
    icon: "flame",
    timestamp: "2h ago",
    sport: "Boxing"
  },
  {
    id: "perf-2",
    type: "ranking",
    userName: "Sarah Mitchell",
    userAvatar: "https://images.unsplash.com/photo-1594381898411-846e7d193883?w=400&h=400&fit=crop",
    text: "Moved to Top 5 in Tennis Dubai Marina",
    metric: "#4",
    icon: "trophy",
    timestamp: "5h ago",
    sport: "Tennis"
  },
  {
    id: "perf-3",
    type: "achievement",
    userName: "Ahmed Al-Rashid",
    userAvatar: "https://images.unsplash.com/photo-1568602471122-7832951cc4c5?w=400&h=400&fit=crop",
    text: "New 10K personal record",
    metric: "38:42",
    icon: "zap",
    timestamp: "1d ago",
    sport: "Running"
  },
  {
    id: "perf-4",
    type: "milestone",
    userName: "Elena Rodriguez",
    userAvatar: "https://images.unsplash.com/photo-1518611012118-696072aa579a?w=400&h=400&fit=crop",
    text: "Completed 50 yoga sessions",
    metric: "50 sessions",
    icon: "target",
    timestamp: "1d ago",
    sport: "Yoga"
  },
  {
    id: "perf-5",
    type: "achievement",
    userName: "Marcus Johnson",
    userAvatar: "https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=400&h=400&fit=crop",
    text: "Deadlift new PR: 180kg",
    metric: "180kg",
    icon: "trophy",
    timestamp: "2d ago",
    sport: "Strength Training"
  }
];

const coachSpotlight: CoachSpotlightItem[] = [
  {
    id: "coach-1",
    coachName: "Marcus Johnson",
    coachAvatar: "https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=400&h=400&fit=crop",
    coachSport: "Strength Training",
    type: "tip",
    title: "Progressive Overload Explained",
    content: "Want to build muscle? Track your weights and increase by 2.5-5% weekly. Small, consistent gains beat random intensity every time.",
    image: "https://images.unsplash.com/photo-1756115484694-009466dbaa67?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    timestamp: "3h ago"
  },
  {
    id: "coach-2",
    coachName: "Jackson Hayes",
    coachAvatar: "https://images.unsplash.com/photo-1549719386-74dfcbf7dbed?w=400&h=400&fit=crop",
    coachSport: "Boxing",
    type: "transformation",
    title: "Client Transformation: 12 Weeks",
    content: "From beginner to sparring-ready in 12 weeks. Consistency and technique beat everything. Book your assessment today.",
    image: "https://images.unsplash.com/photo-1758521960091-4db78cf93a64?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    ctaText: "Book Session",
    timestamp: "6h ago"
  },
  {
    id: "coach-3",
    coachName: "Sarah Mitchell",
    coachAvatar: "https://images.unsplash.com/photo-1594381898411-846e7d193883?w=400&h=400&fit=crop",
    coachSport: "Tennis",
    type: "offer",
    title: "Tennis Beginner Package - 20% Off",
    content: "Limited time: Get 20% off my 8-week beginner program. Perfect technique from day one. Only 3 spots left this month.",
    ctaText: "Claim Offer",
    timestamp: "1d ago"
  },
  {
    id: "coach-4",
    coachName: "Elena Rodriguez",
    coachAvatar: "https://images.unsplash.com/photo-1518611012118-696072aa579a?w=400&h=400&fit=crop",
    coachSport: "Yoga",
    type: "tip",
    title: "Morning Mobility Routine",
    content: "Start your day with this 10-minute flow. Focus on breath and controlled movement. Your body will thank you.",
    image: "https://images.unsplash.com/photo-1552196527-9a20ba4db2c3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    timestamp: "2d ago"
  }
];

const aiCurated: AICuratedItem[] = [
  {
    id: "ai-1",
    title: "Recovery Routine for Boxers",
    description: "Based on your recent boxing sessions, this recovery routine will help prevent overtraining.",
    reason: "You've trained boxing 3x this week",
    image: "https://images.unsplash.com/photo-1552196527-9a20ba4db2c3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    sport: "Recovery",
    type: "routine",
    ctaText: "View Routine"
  },
  {
    id: "ai-2",
    title: "Ahmed Al-Rashid - Running Coach",
    description: "Top-rated running coach specializing in 10K training. 98% client success rate.",
    reason: "Matches your running goals",
    image: "https://images.unsplash.com/photo-1568602471122-7832951cc4c5?w=400&h=400&fit=crop",
    sport: "Running",
    type: "coach",
    ctaText: "View Profile"
  },
  {
    id: "ai-3",
    title: "HIIT & Core Strength Package",
    description: "6-week intensive program combining HIIT cardio with core strengthening. Perfect for fat loss.",
    reason: "Based on your fitness goals",
    image: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    sport: "HIIT",
    type: "package",
    ctaText: "Explore Package"
  }
];

interface HomeProps {
  onNavigateToCoach?: (coachId: string) => void;
  onStartPackage?: (packageId: string) => void;
}

export function Home({ onNavigateToCoach, onStartPackage }: HomeProps) {
  const [aiInput, setAiInput] = useState("");
  const [aiMessages, setAiMessages] = useState<{ role: "user" | "ai"; content: string }[]>([]);
  const [selectedPackage, setSelectedPackage] = useState<Package | null>(null);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [selectedLocation, setSelectedLocation] = useState("Dubai Marina");
  const [showLocationSelector, setShowLocationSelector] = useState(false);
  const [expandedSections, setExpandedSections] = useState({
    highlights: true,
    performance: true,
    coaches: true,
    aiCurated: true,
    packages: false
  });

  const locations = [
    "Dubai Marina",
    "Downtown Dubai",
    "Jumeirah",
    "Business Bay",
    "DIFC",
    "JBR",
    "Palm Jumeirah",
    "Dubai Hills"
  ];

  const localPromotions = [
    {
      id: "1",
      gym: "FitZone Marina",
      promo: "20% off first month",
      image: "https://images.unsplash.com/photo-1758778932790-da96c9f06969?w=600&h=400&fit=crop",
      distance: "0.8 km"
    },
    {
      id: "2",
      gym: "Elite Performance Center",
      promo: "Free assessment session",
      image: "https://images.unsplash.com/photo-1666478042380-ff2b5bf7dd06?w=600&h=400&fit=crop",
      distance: "1.2 km"
    },
    {
      id: "3",
      gym: "Marina Sports Club",
      promo: "New member special",
      image: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=600&h=400&fit=crop",
      distance: "1.5 km"
    }
  ];

  const toggleSection = (section: keyof typeof expandedSections) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  const getIconComponent = (iconName: string) => {
    switch (iconName) {
      case "flame":
        return Flame;
      case "trophy":
        return Trophy;
      case "target":
        return Target;
      case "zap":
        return Zap;
      default:
        return Trophy;
    }
  };

  const handleSendMessage = () => {
    if (!aiInput.trim()) return;

    const userMessage = aiInput;
    setAiMessages([...aiMessages, { role: "user", content: userMessage }]);
    setAiInput("");

    // Simulate AI response
    setTimeout(() => {
      const responses = [
        "That's a great goal! Based on your interests, I'd recommend our '6-Pack in 90 Days' program. It combines strength training with HIIT cardio and includes recovery sessions.",
        "Excellent question! Cross-training is key to avoiding injuries and plateaus. By working with multiple coaches across different disciplines, you'll develop well-rounded fitness.",
        "I can definitely help with that! Looking at your goals, I suggest starting with our beginner programs. Which sport interests you most?",
        "Perfect! The packages include specialized coaches who work together on your journey. You'll have weight training for strength, cardio for endurance, plus recovery work.",
        "Great mindset! Consistency is more important than intensity when starting. Ready to start your transformation?"
      ];
      const randomResponse = responses[Math.floor(Math.random() * responses.length)];
      setAiMessages(prev => [...prev, { role: "ai", content: randomResponse }]);
    }, 1000);
  };

  return (
    <>
      <div id="home-scroll-container" className="h-full bg-[#0f0f0f] overflow-y-auto relative">
        <div className="max-w-md mx-auto pb-20">

          {/* Location Selector */}
          <div className="px-5 pt-5">
            <button
              onClick={() => setShowLocationSelector(!showLocationSelector)}
              className="w-full p-4 bg-[#1a1a1a] hover:bg-white/[0.07] rounded-xl border border-gray-800/30 flex items-center gap-3 transition-all duration-300"
            >
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#c6ff00]/20 to-[#b5e600]/10 flex items-center justify-center border border-[#c6ff00]/30">
                <MapPin className="w-6 h-6 text-[#c6ff00]" />
              </div>
              <div className="flex-1 text-left">
                <div className="text-gray-400 text-sm mb-0.5">Training Location</div>
                <div className="text-white">{selectedLocation}</div>
              </div>
              <ChevronRight className={`w-5 h-5 text-gray-400 transition-transform duration-300 ${showLocationSelector ? 'rotate-90' : ''}`} />
            </button>

            {showLocationSelector && (
              <div className="mt-3 p-2 bg-white/5 rounded-xl border border-white/10">
                <div className="space-y-1">
                  {locations.map((location) => (
                    <button
                      key={location}
                      onClick={() => {
                        setSelectedLocation(location);
                        setShowLocationSelector(false);
                      }}
                      className={`w-full px-4 py-3 rounded-lg text-left transition-all duration-300 ${
                        selectedLocation === location
                          ? "bg-[#c6ff00] text-black"
                          : "text-white/70 hover:bg-white/10"
                      }`}
                    >
                      {location}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Local Promotions */}
          <div className="px-5 pt-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-white">Local Gyms & Offers</h3>
              <TrendingUp className="w-5 h-5 text-[#c6ff00]" />
            </div>
            <div className="flex gap-3 overflow-x-auto pb-3 -mx-5 px-5" style={{ scrollbarWidth: 'none' }}>
              {localPromotions.map((promo) => (
                <div
                  key={promo.id}
                  className="flex-shrink-0 w-64 bg-[#1a1a1a] rounded-xl border border-gray-800/30 overflow-hidden hover:shadow-[0_4px_16px_rgba(0,0,0,0.4)] transition-all duration-300"
                >
                  <div className="relative h-32">
                    <img
                      src={promo.image}
                      alt={promo.gym}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                    <div className="absolute bottom-2 left-2 right-2">
                      <div className="text-white text-sm mb-0.5">{promo.gym}</div>
                      <div className="flex items-center justify-between">
                        <div className="text-[#c6ff00] text-xs">{promo.promo}</div>
                        <div className="flex items-center gap-1 text-white/60 text-xs">
                          <MapPin className="w-3 h-3" />
                          <span>{promo.distance}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Weekly Highlights */}
          <div className="px-5 pt-5">
            <button
              onClick={() => toggleSection('highlights')}
              className="w-full flex items-center justify-between mb-3"
            >
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-[#c6ff00]" />
                <h3 className="text-white">Weekly Highlights</h3>
              </div>
              <ChevronDown className={`w-5 h-5 text-gray-400 transition-transform duration-300 ${expandedSections.highlights ? 'rotate-180' : ''}`} />
            </button>

            {expandedSections.highlights && (
              <div className="space-y-3">
                {/* Stats Card */}
                <div className="bg-gradient-to-br from-[#c6ff00]/10 to-[#b5e600]/5 border border-[#c6ff00]/30 rounded-2xl p-5">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <div className="text-white/60 text-sm">{weeklyHighlights.weekOf}</div>
                      <h4 className="text-white">{weeklyHighlights.title}</h4>
                    </div>
                    <div className="w-12 h-12 rounded-full bg-[#c6ff00]/20 flex items-center justify-center border border-[#c6ff00]/50">
                      <Trophy className="w-6 h-6 text-[#c6ff00]" />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 mb-4">
                    <div className="text-center">
                      <div className="text-2xl text-[#c6ff00] mb-1">{weeklyHighlights.stats.sessions}</div>
                      <div className="text-xs text-white/60">Sessions</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl text-[#c6ff00] mb-1">{weeklyHighlights.stats.calories}</div>
                      <div className="text-xs text-white/60">Calories</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl text-[#c6ff00] mb-1">{weeklyHighlights.stats.streak}</div>
                      <div className="text-xs text-white/60">Day Streak</div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    {weeklyHighlights.achievements.map((achievement, index) => (
                      <div key={index} className="flex items-center gap-2 text-sm text-white/80">
                        <div className="w-1.5 h-1.5 bg-[#c6ff00] rounded-full"></div>
                        <span>{achievement.text}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Coach Update */}
                <div className="bg-[#1a1a1a] border border-white/10 rounded-xl p-4">
                  <div className="flex items-start gap-3 mb-2">
                    <img
                      src={weeklyHighlights.coachUpdate.avatar}
                      alt={weeklyHighlights.coachUpdate.coachName}
                      className="w-10 h-10 rounded-full object-cover"
                    />
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-white text-sm">{weeklyHighlights.coachUpdate.coachName}</span>
                        <div className="px-2 py-0.5 bg-[#c6ff00]/20 border border-[#c6ff00]/30 rounded text-[#c6ff00] text-xs">Coach</div>
                      </div>
                      <p className="text-white/70 text-sm leading-relaxed">{weeklyHighlights.coachUpdate.message}</p>
                    </div>
                  </div>
                </div>

                {/* Community Spotlight */}
                <div className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-500/30 rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Award className="w-5 h-5 text-purple-400" />
                    <span className="text-white text-sm">Community Spotlight</span>
                  </div>
                  <p className="text-white/70 text-sm leading-relaxed">{weeklyHighlights.communitySpotlight}</p>
                </div>
              </div>
            )}
          </div>

          {/* Performance Feed */}
          <div className="px-5 pt-5">
            <button
              onClick={() => toggleSection('performance')}
              className="w-full flex items-center justify-between mb-3"
            >
              <div className="flex items-center gap-2">
                <Trophy className="w-5 h-5 text-[#c6ff00]" />
                <h3 className="text-white">Performance Feed</h3>
              </div>
              <ChevronDown className={`w-5 h-5 text-gray-400 transition-transform duration-300 ${expandedSections.performance ? 'rotate-180' : ''}`} />
            </button>

            {expandedSections.performance && (
              <div className="space-y-2">
                {performanceFeed.map((item) => {
                  const IconComponent = getIconComponent(item.icon);
                  return (
                    <div
                      key={item.id}
                      className="bg-[#1a1a1a] border border-white/10 rounded-xl p-4 hover:border-[#c6ff00]/30 transition-all duration-200"
                    >
                      <div className="flex items-center gap-3">
                        <img
                          src={item.userAvatar}
                          alt={item.userName}
                          className="w-10 h-10 rounded-full object-cover"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-white text-sm truncate">{item.userName}</span>
                            {item.sport && (
                              <div className="px-2 py-0.5 bg-white/5 rounded text-white/60 text-xs flex-shrink-0">
                                {item.sport}
                              </div>
                            )}
                          </div>
                          <p className="text-white/70 text-sm">{item.text}</p>
                        </div>
                        <div className="flex flex-col items-end gap-1 flex-shrink-0">
                          <div className="w-10 h-10 rounded-lg bg-[#c6ff00]/10 flex items-center justify-center border border-[#c6ff00]/30">
                            <IconComponent className="w-5 h-5 text-[#c6ff00]" />
                          </div>
                          {item.metric && (
                            <div className="text-[#c6ff00] text-xs whitespace-nowrap">{item.metric}</div>
                          )}
                        </div>
                      </div>
                      <div className="mt-2 text-xs text-white/40">{item.timestamp}</div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Coach Spotlight */}
          <div className="px-5 pt-5">
            <button
              onClick={() => toggleSection('coaches')}
              className="w-full flex items-center justify-between mb-3"
            >
              <div className="flex items-center gap-2">
                <Star className="w-5 h-5 text-[#c6ff00]" />
                <h3 className="text-white">Coach Spotlight</h3>
              </div>
              <ChevronDown className={`w-5 h-5 text-gray-400 transition-transform duration-300 ${expandedSections.coaches ? 'rotate-180' : ''}`} />
            </button>

            {expandedSections.coaches && (
              <div className="space-y-3">
                {coachSpotlight.map((item) => (
                  <div
                    key={item.id}
                    className="bg-[#1a1a1a] border border-white/10 rounded-xl overflow-hidden hover:border-[#c6ff00]/30 transition-all duration-200"
                  >
                    {item.image && (
                      <div className="relative h-40">
                        <img
                          src={item.image}
                          alt={item.title}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                      </div>
                    )}
                    <div className="p-4">
                      <div className="flex items-center gap-3 mb-3">
                        <img
                          src={item.coachAvatar}
                          alt={item.coachName}
                          className="w-10 h-10 rounded-full object-cover"
                        />
                        <div className="flex-1">
                          <div className="text-white text-sm mb-0.5">{item.coachName}</div>
                          <div className="text-white/60 text-xs">{item.coachSport}</div>
                        </div>
                        <div className="flex items-center gap-1.5 px-2 py-1 bg-[#c6ff00]/10 border border-[#c6ff00]/30 rounded text-[#c6ff00] text-xs">
                          {item.type === 'tip' && <Lightbulb className="w-3.5 h-3.5" />}
                          {item.type === 'transformation' && <Flame className="w-3.5 h-3.5" />}
                          {item.type === 'offer' && <Gift className="w-3.5 h-3.5" />}
                          <span>{item.type === 'tip' ? 'Tip' : item.type === 'transformation' ? 'Story' : 'Offer'}</span>
                        </div>
                      </div>
                      <h4 className="text-white mb-2">{item.title}</h4>
                      <p className="text-white/70 text-sm leading-relaxed mb-3">{item.content}</p>
                      {item.ctaText && (
                        <button className="w-full py-2.5 bg-[#c6ff00] hover:bg-[#b5e600] text-black rounded-lg transition-colors duration-200 flex items-center justify-center gap-2">
                          <span>{item.ctaText}</span>
                          <ArrowRight className="w-4 h-4" />
                        </button>
                      )}
                      <div className="mt-3 text-xs text-white/40">{item.timestamp}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* AI Curated */}
          <div className="px-5 pt-5">
            <button
              onClick={() => toggleSection('aiCurated')}
              className="w-full flex items-center justify-between mb-3"
            >
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-purple-400" />
                <h3 className="text-white">AI Curated for You</h3>
              </div>
              <ChevronDown className={`w-5 h-5 text-gray-400 transition-transform duration-300 ${expandedSections.aiCurated ? 'rotate-180' : ''}`} />
            </button>

            {expandedSections.aiCurated && (
              <div className="space-y-3">
                {aiCurated.map((item) => (
                  <div
                    key={item.id}
                    className="bg-gradient-to-br from-purple-500/5 to-pink-500/5 border border-purple-500/20 rounded-xl overflow-hidden hover:border-purple-500/40 transition-all duration-200"
                  >
                    <div className="relative h-32">
                      <img
                        src={item.image}
                        alt={item.title}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/90 to-transparent" />
                      <div className="absolute top-2 left-2 px-2 py-1 bg-purple-500/20 backdrop-blur-xl border border-purple-400/30 rounded text-purple-300 text-xs">
                        {item.sport}
                      </div>
                    </div>
                    <div className="p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Sparkles className="w-4 h-4 text-purple-400" />
                        <span className="text-purple-300 text-xs">{item.reason}</span>
                      </div>
                      <h4 className="text-white mb-2">{item.title}</h4>
                      <p className="text-white/70 text-sm leading-relaxed mb-3">{item.description}</p>
                      <button className="w-full py-2.5 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white rounded-lg transition-all duration-200 flex items-center justify-center gap-2">
                        <span>{item.ctaText}</span>
                        <ArrowRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Packages Section */}
          <div className="px-5 pt-5 pb-5">
            <button
              onClick={() => toggleSection('packages')}
              className="w-full flex items-center justify-between mb-3"
            >
              <div className="flex items-center gap-2">
                <Dumbbell className="w-5 h-5 text-[#c6ff00]" />
                <h3 className="text-white">Training Packages</h3>
              </div>
              <ChevronDown className={`w-5 h-5 text-gray-400 transition-transform duration-300 ${expandedSections.packages ? 'rotate-180' : ''}`} />
            </button>

            {expandedSections.packages && (
              <div className="space-y-3">
                {packages.map((pkg) => (
                  <button
                    key={pkg.id}
                    onClick={() => setSelectedPackage(pkg)}
                    className="w-full group"
                  >
                    <div className="bg-[#1a1a1a] rounded-2xl border border-gray-800/30 overflow-hidden hover:shadow-[0_8px_32px_rgba(0,0,0,0.4)] transition-all duration-300 hover:border-[#c6ff00]/30">
                      {/* Image */}
                      <div className="relative h-48 overflow-hidden">
                        <img
                          src={pkg.image}
                          alt={pkg.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                        
                        {/* Badge */}
                        <div className="absolute top-3 right-3 px-3 py-1.5 bg-[#c6ff00] rounded-lg text-black text-sm">
                          {pkg.duration}
                        </div>

                        {/* Difficulty */}
                        <div className="absolute top-3 left-3 px-3 py-1.5 bg-white/10 backdrop-blur-xl rounded-lg text-white text-sm border border-white/20">
                          {pkg.difficulty}
                        </div>
                      </div>

                      {/* Content */}
                      <div className="p-5 space-y-3">
                        <div>
                          <h3 className="text-white mb-1 text-left">{pkg.title}</h3>
                          <p className="text-[#c6ff00] text-sm text-left">{pkg.goal}</p>
                        </div>

                        {/* Stats */}
                        <div className="flex items-center gap-4 text-sm text-gray-400">
                          <div className="flex items-center gap-1.5">
                            <Dumbbell className="w-4 h-4" />
                            <span>{pkg.coaches.length} Coaches</span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <Clock className="w-4 h-4" />
                            <span>{pkg.coaches.reduce((sum, c) => sum + c.sessions, 0)} Sessions</span>
                          </div>
                        </div>

                        {/* CTA */}
                        <div className="flex items-center justify-between pt-2 border-t border-black/10">
                          <span className="text-gray-600 text-sm">View Details</span>
                          <ChevronRight className="w-5 h-5 text-[#c6ff00] group-hover:translate-x-1 transition-transform duration-300" />
                        </div>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Floating AI Chat Button */}
          <button
            onClick={() => setIsChatOpen(true)}
            className="fixed bottom-24 right-5 z-20 group"
          >
            <div className="relative">
              {/* Glow effect */}
              <div className="absolute inset-0 bg-[#c6ff00] blur-2xl opacity-50 rounded-full scale-150 group-hover:scale-175 transition-transform duration-300"></div>
              
              {/* Button */}
              <div className="relative w-16 h-16 rounded-full bg-gradient-to-br from-[#c6ff00] via-[#b5e600] to-[#9fd600] flex items-center justify-center shadow-[0_8px_32px_rgba(198,255,0,0.4)] group-hover:shadow-[0_12px_40px_rgba(198,255,0,0.6)] transition-all duration-300 group-active:scale-95 border-2 border-[#c6ff00]/30">
                <Sparkles className="w-8 h-8 text-black animate-pulse" />
              </div>

              {/* Active indicator */}
              <div className="absolute -top-1 -right-1 w-4 h-4 bg-[#c6ff00] rounded-full border-2 border-white animate-pulse"></div>
            </div>
          </button>
        </div>

        {/* Package Detail Modal */}
        {selectedPackage && (
          <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-sm animate-fade-in">
            <div className="h-full overflow-y-auto">
              <div className="max-w-md mx-auto bg-[#0f0f0f] min-h-full">
                {/* Header Image */}
                <div className="relative h-64">
                  <img
                    src={selectedPackage.image}
                    alt={selectedPackage.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-[#0f0f0f]" />
                  
                  {/* Close Button */}
                  <button
                    onClick={() => setSelectedPackage(null)}
                    className="absolute top-5 right-5 w-10 h-10 bg-white/10 backdrop-blur-xl hover:bg-white/20 rounded-full flex items-center justify-center transition-all duration-200"
                  >
                    <X className="w-6 h-6 text-white" />
                  </button>

                  {/* Badge */}
                  <div className="absolute top-5 left-5 px-3 py-1.5 bg-[#c6ff00] rounded-lg text-black text-sm">
                    {selectedPackage.duration}
                  </div>
                </div>

                {/* Content */}
                <div className="px-5 pb-20">
                  <div className="py-6 space-y-6">
                    {/* Title */}
                    <div>
                      <h2 className="text-white mb-2">{selectedPackage.title}</h2>
                      <p className="text-[#c6ff00]">{selectedPackage.goal}</p>
                    </div>

                    {/* Description */}
                    <div>
                      <h3 className="text-white mb-3">About This Program</h3>
                      <p className="text-white/70 text-sm leading-relaxed">{selectedPackage.description}</p>
                    </div>

                    {/* Coaches */}
                    <div>
                      <h3 className="text-white mb-3">Your Coaches</h3>
                      <div className="space-y-3">
                        {selectedPackage.coaches.map((coach, index) => (
                          <div
                            key={index}
                            className="bg-[#1a1a1a] border border-white/10 rounded-xl p-4"
                          >
                            <div className="flex items-center gap-3 mb-2">
                              <img
                                src={coach.image}
                                alt={coach.name}
                                className="w-12 h-12 rounded-full object-cover"
                              />
                              <div className="flex-1">
                                <h4 className="text-white tracking-tight">{coach.name}</h4>
                                <p className="text-sm text-white/40">{coach.sport}</p>
                              </div>
                              <div className="text-[#c6ff00] text-sm">{coach.sessions} sessions</div>
                            </div>
                            <p className="text-xs text-white/60 leading-relaxed">{coach.focus}</p>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Highlights */}
                    <div>
                      <h3 className="text-white mb-3">What's Included</h3>
                      <div className="space-y-2">
                        {selectedPackage.highlights.map((highlight, index) => (
                          <div key={index} className="flex items-start gap-3">
                            <div className="w-5 h-5 rounded-full bg-[#c6ff00]/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                              <div className="w-2 h-2 bg-[#c6ff00] rounded-full"></div>
                            </div>
                            <p className="text-white/70 text-sm flex-1">{highlight}</p>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Expected Results */}
                    <div>
                      <h3 className="text-white mb-3">Expected Results</h3>
                      <div className="space-y-2">
                        {selectedPackage.expectedResults.map((result, index) => (
                          <div key={index} className="flex items-start gap-3">
                            <Trophy className="w-5 h-5 text-[#c6ff00] flex-shrink-0 mt-0.5" />
                            <p className="text-white/70 text-sm flex-1">{result}</p>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* CTA Button */}
                    <button
                      onClick={() => {
                        setSelectedPackage(null);
                        onStartPackage?.(selectedPackage.id);
                      }}
                      className="w-full py-4 bg-[#c6ff00] hover:bg-[#b5e600] text-black rounded-xl transition-all duration-200 flex items-center justify-center gap-2"
                    >
                      <span>Start This Package</span>
                      <ArrowRight className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* AI Chat Modal */}
      {isChatOpen && (
        <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-sm">
          <div className="h-full flex flex-col max-w-md mx-auto">
            {/* Header */}
            <div className="flex items-center justify-between p-5 border-b border-white/10">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#c6ff00] to-[#b5e600] flex items-center justify-center">
                  <Sparkles className="w-6 h-6 text-black" />
                </div>
                <div>
                  <h3 className="text-white">VITA AI Guide</h3>
                  <p className="text-xs text-white/60">Your personal fitness assistant</p>
                </div>
              </div>
              <button
                onClick={() => setIsChatOpen(false)}
                className="w-10 h-10 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center transition-all duration-200"
              >
                <X className="w-6 h-6 text-white" />
              </button>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-5 space-y-4">
              {aiMessages.length === 0 ? (
                <div className="text-center py-12">
                  <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-gradient-to-br from-[#c6ff00]/20 to-[#b5e600]/10 flex items-center justify-center border border-[#c6ff00]/30">
                    <Sparkles className="w-10 h-10 text-[#c6ff00]" />
                  </div>
                  <h4 className="text-white mb-2">Ask me anything!</h4>
                  <p className="text-white/60 text-sm">I can help you find the perfect package, coach, or answer any fitness questions.</p>
                </div>
              ) : (
                aiMessages.map((message, index) => (
                  <div
                    key={index}
                    className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
                  >
                    <div
                      className={`max-w-[80%] px-4 py-3 rounded-2xl ${
                        message.role === "user"
                          ? "bg-[#c6ff00] text-black"
                          : "bg-white/10 text-white"
                      }`}
                    >
                      <p className="text-sm leading-relaxed">{message.content}</p>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Input */}
            <div className="p-5 border-t border-white/10">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={aiInput}
                  onChange={(e) => setAiInput(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                  placeholder="Ask about packages, coaches, or goals..."
                  className="flex-1 px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder:text-white/40 focus:outline-none focus:border-[#c6ff00]/50 transition-colors"
                />
                <button
                  onClick={handleSendMessage}
                  className="w-12 h-12 bg-[#c6ff00] hover:bg-[#b5e600] rounded-xl flex items-center justify-center transition-all duration-200 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
                  disabled={!aiInput.trim()}
                >
                  <Send className="w-5 h-5 text-black" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}