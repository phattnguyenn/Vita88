import {
  DollarSign,
  TrendingUp,
  Calendar,
  CreditCard,
  Download,
  PieChart as PieChartIcon,
} from "lucide-react";
import {
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";

const monthlyRevenue = [
  { month: "Jun", revenue: 3200 },
  { month: "Jul", revenue: 3800 },
  { month: "Aug", revenue: 4200 },
  { month: "Sep", revenue: 4800 },
  { month: "Oct", revenue: 5400 },
  { month: "Nov", revenue: 6200 },
];

const packageBreakdown = [
  { name: "Boxing Fundamentals", value: 60, color: "#c6ff00" },
  { name: "Advanced Sparring", value: 25, color: "#00d9ff" },
  { name: "Yoga & Mindfulness", value: 15, color: "#ff00d9" },
];

export function CoachEarnings() {
  return (
    <div className="bg-[#0A0A0A]">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-[#0f0f0f]/95 backdrop-blur-xl border-b border-white/10">
        <div className="max-w-7xl mx-auto px-5 py-4">
          <h1 className="text-white text-2xl">Earnings & Analytics</h1>
          <p className="text-white/60 text-sm mt-1">Track your revenue and business performance</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-5 py-6 pb-32 space-y-6">
        {/* Revenue Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-gradient-to-br from-[#c6ff00]/20 to-[#0f0f0f] rounded-xl p-5 border border-[#c6ff00]/30">
            <div className="flex items-center gap-2 text-[#c6ff00] text-sm mb-2">
              <DollarSign className="w-4 h-4" />
              Total Revenue
            </div>
            <p className="text-white text-3xl mb-1">$28,600</p>
            <p className="text-[#c6ff00] text-sm flex items-center gap-1">
              <TrendingUp className="w-3 h-3" />
              +24% this month
            </p>
          </div>

          <div className="bg-[#0f0f0f] rounded-xl p-5 border border-white/10">
            <div className="flex items-center gap-2 text-white/60 text-sm mb-2">
              <Calendar className="w-4 h-4" />
              This Month
            </div>
            <p className="text-white text-3xl mb-1">$6,200</p>
            <p className="text-white/60 text-sm">Nov 2025</p>
          </div>

          <div className="bg-[#0f0f0f] rounded-xl p-5 border border-white/10">
            <div className="flex items-center gap-2 text-white/60 text-sm mb-2">
              <CreditCard className="w-4 h-4" />
              Available
            </div>
            <p className="text-white text-3xl mb-1">$5,580</p>
            <p className="text-white/60 text-sm">After 10% fee</p>
          </div>

          <div className="bg-[#0f0f0f] rounded-xl p-5 border border-white/10">
            <div className="flex items-center gap-2 text-white/60 text-sm mb-2">
              <Download className="w-4 h-4" />
              Pending
            </div>
            <p className="text-white text-3xl mb-1">$620</p>
            <p className="text-white/60 text-sm">Processing</p>
          </div>
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Revenue Trend */}
          <div className="bg-[#0f0f0f] rounded-[24px] p-6 border border-white/10">
            <h2 className="text-white text-xl mb-5">Revenue Over Time</h2>
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={monthlyRevenue}>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" />
                <XAxis dataKey="month" stroke="#9B9B9B" fontSize={12} />
                <YAxis stroke="#9B9B9B" fontSize={12} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#1a1a1a",
                    border: "1px solid #ffffff20",
                    borderRadius: "8px",
                  }}
                />
                <Line
                  type="monotone"
                  dataKey="revenue"
                  stroke="#c6ff00"
                  strokeWidth={3}
                  dot={{ fill: "#c6ff00", r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Package Breakdown */}
          <div className="bg-[#0f0f0f] rounded-[24px] p-6 border border-white/10">
            <h2 className="text-white text-xl mb-5">Revenue by Package</h2>
            <div className="flex items-center justify-center">
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie
                    data={packageBreakdown}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={90}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {packageBreakdown.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="space-y-2 mt-4">
              {packageBreakdown.map((item) => (
                <div key={item.name} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: item.color }}
                    />
                    <span className="text-white/80 text-sm">{item.name}</span>
                  </div>
                  <span className="text-white">{item.value}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* AI Financial Insight */}
        <div className="bg-gradient-to-br from-[#c6ff00]/10 to-transparent rounded-[24px] p-5 border border-[#c6ff00]/20">
          <div className="flex items-start gap-3">
            <TrendingUp className="w-5 h-5 text-[#c6ff00] flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-white mb-2">AI Financial Insights</p>
              <p className="text-white/60 text-sm mb-3">
                Your "Boxing Fundamentals" package generates 60% of your income. Consider creating
                an advanced version to upsell and increase average client lifetime value by an
                estimated 35%.
              </p>
              <button className="px-4 py-2 bg-[#c6ff00] hover:bg-[#b8f000] text-black rounded-lg text-sm transition-colors">
                View Recommendations
              </button>
            </div>
          </div>
        </div>

        {/* Payout Section */}
        <div className="bg-[#0f0f0f] rounded-[24px] p-6 border border-white/10">
          <div className="flex items-center justify-between mb-5">
            <h2 className="text-white text-xl">Payout Settings</h2>
            <button className="px-4 py-2 bg-[#c6ff00] hover:bg-[#b8f000] text-black rounded-xl text-sm transition-colors">
              Withdraw to Bank
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5">
              <p className="text-white/60 text-sm mb-2">Payment Method</p>
              <p className="text-white">Bank Account •••• 4532</p>
            </div>
            <div className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5">
              <p className="text-white/60 text-sm mb-2">Next Payout</p>
              <p className="text-white">November 10, 2025</p>
            </div>
          </div>

          <div className="mt-4 p-4 bg-white/5 rounded-xl border border-white/5">
            <p className="text-white/60 text-sm mb-1">VITA Service Fee</p>
            <p className="text-white text-sm">10% per transaction (industry standard)</p>
          </div>
        </div>
      </div>
    </div>
  );
}
