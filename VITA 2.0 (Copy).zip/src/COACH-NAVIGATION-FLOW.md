# Coach Navigation Flow Guide

## Complete Coach Interface Navigation

### 🎯 User Journey: Coach Mode

```
┌─────────────────────────────────────────────────────────────┐
│                     AUTH PAGE                                │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  Sign Up as Athlete  │  Sign Up as Coach  │  Login  │   │
│  └────────────┬──────────────────┬──────────────┬──────┘   │
│               │                  │              │            │
└───────────────┼──────────────────┼──────────────┼───────────┘
                │                  │              │
                │                  ▼              │
                │         ┌────────────────┐      │
                │         │  COACH MODE    │      │
                │         │  (userMode =   │      │
                │         │   "coach")     │      │
                │         └────────┬───────┘      │
                │                  │              │
                ▼                  ▼              ▼
         ┌──────────────────────────────────────────────┐
         │           ATHLETE INTERFACE                   │
         │   (Home, Calendar, Coaches, Messages,        │
         │    Profile + Bottom Navigation)              │
         └──────────────────────────────────────────────┘
                                  │
                                  │
                    ┌─────────────┴──────────────┐
                    │                             │
                    ▼                             ▼
         ┌────────────────────┐       ┌────────────────────┐
         │  COACH DASHBOARD   │       │  CLIENT DETAIL     │
         │  (coachView =      │◄──────┤  (coachView =      ��
         │   "dashboard")     │       │   "clientDetail")  │
         └────────┬───────────┘       └────────────────────┘
                  │                             ▲
                  │                             │
                  │   Click Client Card         │
                  └─────────────────────────────┘
```

---

## Detailed Screen Flow

### 1️⃣ Authentication → Coach Mode

**Trigger**: User clicks "Sign Up as Coach" on Auth page

**State Changes**:
```typescript
setUserMode("coach");
setActiveTab("home");
```

**Result**: Skips athlete UI entirely, loads Coach Dashboard

---

### 2️⃣ Coach Dashboard (Main Command Center)

**Route**: `userMode === "coach" && coachView === "dashboard"`

**Features**:
- ✅ Top navigation bar (Logo, Notifications, Settings)
- ✅ Earnings summary cards (4 stats)
- ✅ Upcoming sessions list
- ✅ **Client Management Section** ← Entry point to Client Detail
- ✅ Performance analytics
- ✅ Income breakdown
- ✅ Notifications sidebar
- ✅ Sticky footer CTA bar

**Interactive Elements**:
```tsx
{clients.map((client) => (
  <div
    onClick={() => onClientSelect?.(client.id.toString())}
    className="... cursor-pointer hover:border-[#c6ff00]/30 ..."
  >
    {/* Client card content */}
  </div>
))}
```

---

### 3️⃣ Client Detail (Performance Lab)

**Trigger**: Click any client card from "Your Clients" section

**State Changes**:
```typescript
setSelectedClientId(client.id);
setCoachView("clientDetail");
```

**Route**: `userMode === "coach" && coachView === "clientDetail" && selectedClientId`

**Navigation**:
```tsx
// In CoachDashboard
<div onClick={() => onClientSelect?.(client.id.toString())}>
  {/* Huy Nguyen card */}
</div>

// In App.tsx
if (coachView === "clientDetail" && selectedClientId) {
  return (
    <ClientDetail
      clientId={selectedClientId}
      onBack={() => {
        setCoachView("dashboard");
        setSelectedClientId("");
      }}
    />
  );
}
```

**Back Navigation**:
```tsx
// ClientDetail header
<button onClick={onBack}>
  <ArrowLeft /> Back to Dashboard
</button>
```

---

## Visual Flow Diagram

```
┌──────────────────────────────────────────────────────────────┐
│                     COACH DASHBOARD                          │
├──────────────────────────────────────────────────────────────┤
│  Header: VITΛ [COACH] | 🔔 ⚙️ [Avatar]                      │
├──────────────────────────────────────────────────────────────┤
│  Earnings Cards: $2,840 | 18 Sessions | 12 Clients | 4.9⭐  │
├──────────────────────────────────────────────────────────────┤
│  Upcoming Sessions                                            │
│    9:00 AM — Huy Nguyen 🥊 Boxing                            │
│    11:00 AM — Linh Tran 🧘 Yoga                              │
├──────────────────────────────────────────────────────────────┤
│  YOUR CLIENTS                                 [View All →]   │
│  ┌─────────────────┐  ┌─────────────────┐                   │
│  │ 👤 Huy Nguyen  │  │ 👤 Linh Tran   │  ← CLICK HERE      │
│  │ Flow 72        │  │ Flow 58        │                     │
│  │ Improving 📈   │  │ Stable ⚖️      │                     │
│  └─────────────────┘  └─────────────────┘                   │
│                  ⬇ (onClick handler)                         │
├──────────────────────────────────────────────────────────────┤
│  Performance Analytics | Income | Notifications              │
├──────────────────────────────────────────────────────────────┤
│  [Add New Session] [View Coach Profile]                      │
└──────────────────────────────────────────────────────────────┘
                           │
                           │ Click "Huy Nguyen"
                           ▼
┌──────────────────────────────────────────────────────────────┐
│                    CLIENT DETAIL: Huy Nguyen                  │
├──────────────────────────────────────────────────────────────┤
│  [← Back to Dashboard]                                       │
├──────────────────────────────────────────────────────────────┤
│  ┌────────────────────────────────────────────────────┐      │
│  │ 👤 Huy Nguyen | 🇻🇳 Ho Chi Minh City             │      │
│  │ Boxing & Core Stability | Flow [72]               │      │
│  │ Active                                             │      │
│  │ 📅 124 Sessions | ⏰ 186 Hours | 🔥 21-Day Streak  │      │
│  └────────────────────────────────────────────────────┘      │
├──────────────────────────────────────────────────────────────┤
│  Performance Overview                                         │
│  ┌──────────────────┐  ┌──────────────────┐                 │
│  │ Line Chart:      │  │ Bar Chart:       │                 │
│  │ Flow Over Time   │  │ Attendance       │                 │
│  └──────────────────┘  └──────────────────┘                 │
│  [Speed 78%] [Power 82%] [Endurance 71%] [Technique 85%]    │
│  💡 AI: "Speed +7%, technique +5%. Suggest 2 more drills"   │
├──────────────────────────────────────────────────────────────┤
│  Session History              │  Current Goals               │
│  🥊 29 Oct — Boxing ✅ 9/10   │  🎯 Master defense (70%)    │
│  🧘 27 Oct — Yoga ✅          │  🎯 3-round stamina (45%)   │
│  💪 25 Oct — Strength ❌      │  🎯 Consistency (100%) 🔥   │
│                               │                              │
│  Coach Notes & Feedback       │  Quick Chat                  │
│  [Add new note...]            │  Coach: Great session! 👍   │
│  ☐ Share with client          │  Client: Thanks! 👊         │
│  [Add Note]                   │  [Open Full Chat]           │
├──────────────────────────────────────────────────────────────┤
│  [Schedule Session] [Add Note] [Send Message]  ← Sticky     │
└──────────────────────────────────────────────────────────────┘
```

---

## State Management

### Global App State (App.tsx)
```typescript
const [userMode, setUserMode] = useState<"athlete" | "coach">("athlete");
const [coachView, setCoachView] = useState<"dashboard" | "clientDetail">("dashboard");
const [selectedClientId, setSelectedClientId] = useState<string>("");
```

### Navigation Logic
```typescript
// Coach Dashboard → Client Detail
const handleClientSelect = (clientId: string) => {
  setSelectedClientId(clientId);
  setCoachView("clientDetail");
};

// Client Detail → Coach Dashboard
const handleBackToDashboard = () => {
  setCoachView("dashboard");
  setSelectedClientId("");
};
```

---

## Current Clients (Mock Data)

### Available Client Cards
1. **Huy Nguyen** (id: 1)
   - Flow Index: 72
   - Trend: Improving 📈
   - Streak: 12 days
   - Sport: Boxing 🥊

2. **Linh Tran** (id: 2)
   - Flow Index: 58
   - Trend: Stable ⚖️
   - Streak: 8 days
   - Sport: Yoga 🧘

3. **Khoa Le** (id: 3)
   - Flow Index: 45
   - Trend: At Risk ⚠️
   - Streak: 3 days
   - Sport: Strength 💪

4. **Mai Pham** (id: 4)
   - Flow Index: 68
   - Trend: Improving 📈
   - Streak: 15 days
   - Sport: Boxing 🥊

**Note**: Currently, all clients open the same Client Detail screen (Huy Nguyen profile). In production, clientId would fetch different data.

---

## Interactive Hotspots

### On Coach Dashboard
```
┌─────────────────────────────────────┐
│ YOUR CLIENTS                        │
│ ┌──────────────┐ ┌──────────────┐  │
│ │ ← CLICKABLE  │ │ ← CLICKABLE  │  │ ← Hover shows lime border glow
│ │   CARD       │ │   CARD       │  │
│ └──────────────┘ └──────────────┘  │
└─────────────────────────────────────┘
     ↓ onClick
     ↓ onClientSelect(client.id)
     ↓ Navigate to ClientDetail
```

### On Client Detail
```
┌──────────────────────────────────────┐
│ [← Back to Dashboard] ← CLICKABLE    │ ← Returns to Coach Dashboard
└──────────────────────────────────────┘

┌──────────────────────────────────────┐
│ Session History                       │
│ ┌──────────────┐ ← EXPANDABLE        │ ← Click to show/hide notes
│ │ 🥊 Boxing ✅  │                     │
│ │ [Notes...]   │                     │
│ └──────────────┘                     │
└──────────────────────────────────────┘

┌──────────────────────────────────────┐
│ [Schedule] [Add Note] [Message]      │ ← All CLICKABLE (sticky footer)
└──────────────────────────────────────┘
```

---

## Breadcrumb Navigation

```
VITΛ Coach
  └─ Dashboard
       └─ Clients
            └─ Huy Nguyen (Client Detail)
                 └─ [Back to Dashboard]
```

---

## Key Features by Screen

### Coach Dashboard
- 📊 **Analytics**: Revenue, sessions, retention
- 👥 **Client Grid**: Quick overview of all clients
- 📅 **Schedule**: Upcoming sessions
- 💰 **Income**: Breakdown by package
- 🔔 **Notifications**: AI suggestions

### Client Detail
- 📈 **Performance**: Charts and metrics
- 📝 **History**: Session logs with notes
- 🎯 **Goals**: Progress tracking
- 💬 **Chat**: Quick communication
- ⚡ **Actions**: Schedule, note, message

---

## URL Structure (Future Enhancement)

Currently client selection is state-based. For production:

```
/coach/dashboard
/coach/clients/:clientId
/coach/sessions
/coach/earnings
/coach/settings
```

---

## Testing the Flow

### Step-by-Step Test
1. ✅ Launch app → Auth screen
2. ✅ Click "Sign Up as Coach"
3. ✅ Fill form → Submit
4. ✅ **Coach Dashboard loads** (with VITΛ [COACH] logo)
5. ✅ Scroll to "Your Clients" section
6. ✅ **Hover over "Huy Nguyen" card** (lime border glow)
7. ✅ **Click "Huy Nguyen" card**
8. ✅ **Client Detail screen loads** (with client snapshot)
9. ✅ View all 7 sections (header, performance, sessions, notes, goals, chat, actions)
10. ✅ Click session entries to expand/collapse
11. ✅ Test filter tabs (All/Completed/Missed)
12. ✅ **Click "Back to Dashboard"**
13. ✅ **Returns to Coach Dashboard**
14. ✅ Try clicking different client cards (Linh Tran, Khoa Le, Mai Pham)

---

## Edge Cases

### ✅ Handled
- No selected client (coachView guards render)
- Back navigation clears state
- Filter with empty results (shows all by default)
- Responsive behavior (mobile/tablet/desktop)

### ⏳ Not Yet Handled (Future)
- Invalid client ID
- Loading states during data fetch
- Error handling for failed API calls
- Deep linking to specific client
- Browser back button navigation

---

## Performance Notes

### Optimized
- ✅ Conditional rendering (only active view)
- ✅ No unnecessary re-renders
- ✅ Filtered arrays instead of full iteration
- ✅ Recharts lazy loads charts

### Could Improve
- ⏳ Implement React.memo for client cards
- ⏳ Virtualize long session lists
- ⏳ Cache client data
- ⏳ Prefetch adjacent clients

---

## Summary

**Navigation Path**:
```
Auth → Sign Up as Coach → Coach Dashboard → Click Client Card → Client Detail → Back → Dashboard
```

**Key Components**:
- `Auth.tsx` - Entry point
- `App.tsx` - Routing logic
- `CoachDashboard.tsx` - Main hub
- `ClientDetail.tsx` - Individual client view

**State Flow**:
```
userMode: "coach"
  → coachView: "dashboard"
      → Click client
          → coachView: "clientDetail"
          → selectedClientId: "1"
              → Render ClientDetail
              → Click back
                  → coachView: "dashboard"
                  → selectedClientId: ""
```

---

**Status**: ✅ Fully Functional
**Last Updated**: November 2, 2025
