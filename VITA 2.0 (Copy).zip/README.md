
  # VITA 2.0 (Copy)

  This is a code bundle for VITA 2.0 (Copy). The original project is available at https://www.figma.com/design/qdXLtnxnrVoVOrpPh4y6mk/VITA-2.0--Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  